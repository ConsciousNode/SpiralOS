import "/src/app_abi.sp";
void app_draw(int x, int y, int w, int h) {
  gui_set_win(x, y, w, h);
  int st = abi_state();
  wstr(6, 16, "CPU:", 11);
  wstr(42, 16, abi_os_machine_name(), 15);
  wstr(6, 26, "RAM KB:", 11);
  wnum(66, 26, hal_info(1) / 1024, 14);
  wstr(6, 36, "HeapF:", 11);
  wnum(58, 36, abi_heap_free_bytes() / 1024, 10);
  wstr(6, 46, "HeapU:", 11);
  wnum(58, 46, abi_heap_used_bytes() / 1024, 15);
  wstr(6, 56, "Preempt:", 11);
  wnum(74, 56, r32(0x0FFF10), 10);
  wstr(6, 66, "Frames:", 11);
  wnum(66, 66, r32(st + 32), 14);
  wstr(6, 76, "DiskF:", 11);
  wnum(58, 76, abi_fs_free() / 1024, 15);
}
void app_key(int ascii, int vk, int mods) { }
