/**
 * SpiralOS 1.1 — Hummingbird i586 Native Core
 * (Stage 1 Boot Sector + Stage 2 Track-Safe Loader & BIOS Thunk + 32-Bit Protected-Mode Core)
 * Studio: ConsciousNode SoftWorks · Licence: MIT
 *
 * Uses core/x86_asm.js to build:
 *   1. Sector 0 (512B at 0x7C00): Stage 1 BIOS Boot Sector (FAT12 BPB, boot banner at 0x180,
 *      3-retry INT 13h load of Stage 2 to 0x7E00, GDT with 32-bit & 16-bit descriptors)
 *   2. Sector 1 (512B at 0x7E00): Stage 2 Real-Mode Loader (track-safe LBA-to-CHS reader
 *      that never crosses 18-sector track boundaries, 3-retry CF error check, VBE 32/24-bpp
 *      mode scanner, PhysBasePtr page-directory mapper, and Real-Mode INT 13h AH=03h write thunk)
 *   3. Sectors 2..31 (at 0x8000): 32-bit x86 Protected-Mode Kernel + Hardware Drivers
 *      (8259A PIC + 8254 PIT IRQ0 timer ISR + Preemptive VM Task Scheduler, PS/2 keyboard & mouse,
 *      VBE 24-bpp & 32-bpp 2x LFB blitter, 82077AA FDC + BIOS INT 13h fallback sync,
 *      StudioNet presence detection & port I/O, PIT speaker) + Spiral VM Interpreter.
 */

"use strict";

const { R, X86Builder } = (typeof globalThis !== "undefined" && globalThis.X86Builder)
  ? { R: globalThis.X86Reg, X86Builder: globalThis.X86Builder }
  : require("./x86_asm.js");

// from fonts/consciousnode-sans-8x8.hex:1-96
const X86_FONT_8X8_HEX =
  "00000000000000001010101000101000444444000000000048fc4848fc480000" +
  "107c907814f81000c4c810204c8c000070887094887400001010200000000000" +
  "081020202010080020100808081020000054387c385400000010107c10100000" +
  "00000000001810200000007c0000000000000000003030000408102040800000" +
  "788c94a4c48478001030501010107c00788404384080fc00f808103804847800" +
  "08182848fc080800fc80f80404847800384080f884847800fc04081020202000" +
  "78844830488478007884847c0408700000303000303000000018180018102000" +
  "081020402010080000007c007c00000040201008102040007884081010001000" +
  "7884bca4bc807c00304884fc84848400f88484f88484f8007884808080847800" +
  "f08884848488f000fc8080f88080fc00fc8080f8808080007884809c84847800" +
  "848484fc848484007c10101010107c003c08080888887000848890e090888400" +
  "808080808080fc0082c6aa928282820084c4a4948c8484007884848484847800" +
  "f88484f88080800078848484a4947a00f88484f8908884007884807804847800" +
  "fe101010101010008484848484847800848484484830300082828292aac68200" +
  "84483030304884008448301010101000fc0810204080fc003820202020203800" +
  "804020100804000038080808080838001028440000000000000000000000fe00" +
  "2010000000000000000078047c847c008080f8848484f8000000788480847800" +
  "04047c8484847c0000007884fc8078001c20f8202020200000007c84847c0478" +
  "8080f884848484001000301010103800080018080808887080808890e0908800" +
  "20202020202018000000ec92929292000000f088888888000000788484847800" +
  "0000f88484f8808000007c84847c040400009cc28080800000007c807804f800" +
  "2020f8202024180000008484848c740000008484484830000000829292aa4400" +
  "000084483048840000008484483010600000fc083040fc001820204020201800" +
  "101010101010100030080804080830000064980000000000007c547c547c0000";

// from fonts/cnsw-serif-8x16.hex:1-96
const X86_FONT_SERIF_8X16_HEX =
  "0000000000000000000000000000000000303030303010100000303000000000" +
  "0066664444000000000000000000000000004444fe4444fe4444000000000000" +
  "00107c9290781412927c1000000000000000c4c8101020204c8c000000000000" +
  "0038444438508a848c7200000000000000303040400000000000000000000000" +
  "000c1020204040402020100c0000000000601008080404040808106000000000" +
  "0000001054387c3854100000000000000000000010107c101000000000000000" +
  "00000000000000000000303010200000000000000000007c0000000000000000" +
  "0000000000000000000030300000000000040408081010202040408000000000" +
  "003844868a92a2c2828244380000000000103050101010101010107c00000000" +
  "0078848404081020408084fc0000000000788404043804040484847800000000" +
  "00081828488888fc0808083c0000000000fc848080f804040484847800000000" +
  "0038448080f88484848444380000000000fc8404080810102020203800000000" +
  "007884844830304884848478000000000078848484847c040408483000000000" +
  "0000000000303000000030300000000000000000003030000000303010200000" +
  "0000000810204020100800000000000000000000007c00007c00000000000000" +
  "0000004020100810204000000000000000788484040810100000101000000000" +
  "00788484bca4a4bc8080403c0000000000382844444482fe828282c600000000" +
  "00f8444444784442424244f800000000003c4484808080808084443800000000" +
  "00f8444242424242424244f80000000000fc444050705040404044fc00000000" +
  "00fc444050705040404040e000000000003c448480809c848484443800000000" +
  "00c6444444447c44444444c600000000007c1010101010101010107c00000000" +
  "003e080808080808888888700000000000c6485060406050484444c600000000" +
  "00e0404040404040404044fc0000000000c6ee5454544444444444c600000000" +
  "00c66454544c4c44444444c60000000000384482828282828282443800000000" +
  "00f844444444f840404040e0000000000038448282828282928a463a00000000" +
  "00f844444444f850484444c600000000007c848040380404048484f800000000" +
  "00fe921010101010101010380000000000c64444444444444444443800000000" +
  "00c6444444444428282810100000000000c64444445454545428282800000000" +
  "00c6442828101010282844c60000000000c64428281010101010103800000000" +
  "00fc840808102020408084fc0000000000382020202020202020203800000000" +
  "0080804040202010100808040000000000380808080808080808083800000000" +
  "00102844000000000000000000000000000000000000000000000000fe000000" +
  "0020100000000000000000000000000000000000007884047c84847c00000000" +
  "00c0404040784442424244f80000000000000000007884808080847800000000" +
  "000c0404043c44848484443c000000000000000000788484fc80847800000000" +
  "001c2420207c2020202020700000000000000000007c888870807c8484443800" +
  "00c0404040586444444444cc0000000000001000003010101010103800000000" +
  "0000080000180808080808088888700000c04040404c5060504848cc00000000" +
  "002060202020202020202070000000000000000000d45454545454d600000000" +
  "0000000000d84444444444cc0000000000000000007884848484847800000000" +
  "0000000000f84444444444784040e00000000000007c88888888887808081c00" +
  "0000000000dc4440404040e00000000000000000007c8440380484f800000000" +
  "00000020207c202020202418000000000000000000cc444444444c3600000000" +
  "0000000000cc484848303030000000000000000000c644545454282800000000" +
  "0000000000cc4830303048cc000000000000000000cc4848303010102040c000" +
  "0000000000fc8810204088fc0000000000182020204040202020201800000000" +
  "0010101010101010101010100000000000300808080404080808083000000000" +
  "0000006498000000000000000000000000000038549292925438000000000000";

function buildBootSector(customBanner = "SpiralOS 1.6") {
  const b = new Uint8Array(512);
  const dv = new DataView(b.buffer);

  // FAT12-compatible BPB (1.44 MB 3.5" floppy: 18 spt, 2 heads, 2880 sectors)
  b[0] = 0xEB; b[1] = 0x3C; b[2] = 0x90;
  const oem = "SPIRALOS";
  for (let i = 0; i < 8; i++) b[3 + i] = oem.charCodeAt(i);
  dv.setUint16(11, 512, true);
  b[13] = 1;
  dv.setUint16(14, 1, true);
  b[16] = 2;
  dv.setUint16(17, 224, true);
  dv.setUint16(19, 2880, true);
  b[21] = 0xF0;
  dv.setUint16(22, 9, true);
  dv.setUint16(24, 18, true);
  dv.setUint16(26, 2, true);

  let p = 0x3E;
  const put = (...arr) => { for (const v of arr) b[p++] = v & 0xFF; };
  const put16 = (v) => { b[p++] = v & 0xFF; b[p++] = (v >>> 8) & 0xFF; };

  // 16-bit Real Mode entry at 0x7C3E
  put(0xFA);                         // cli
  put(0x31, 0xC0);                   // xor ax, ax
  put(0x8E, 0xD8);                   // mov ds, ax
  put(0x8E, 0xC0);                   // mov es, ax
  put(0x8E, 0xD0);                   // mov ss, ax
  put(0xBC); put16(0x7C00);          // mov sp, 0x7C00
  put(0x88, 0x16); put16(0x7DFC);    // mov [0x7DFC], dl (save boot drive)
  put(0xFB);                         // sti
  // 1. Print 'S' via INT 10h AH=0Eh (triggers Milestone 1: Boot sector runs)
  put(0xB8); put16(0x0E53);          // mov ax, 0x0E53
  put(0x31, 0xDB);                   // xor bx, bx
  put(0xCD, 0x10);                   // int 10h

  // 2. Write banner from 0x7D80 (offset 0x180) onto row 2 of 0xB8000 and call INT 16h AH=01h
  put(0xB8); put16(0xB800);          // mov ax, 0xB800
  put(0x8E, 0xC0);                   // mov es, ax
  put(0xBE); put16(0x7D80);          // mov si, 0x7D80
  put(0xBF); put16(2 * 160 + 4);     // mov di, 324
  const bannerLoop = p;
  put(0xAC);                         // lodsb
  put(0x84, 0xC0);                   // test al, al
  put(0x74, 0x06);                   // jz +6
  put(0xB4, 0x1F);                   // mov ah, 0x1F
  put(0xAB);                         // stosw
  put(0xEB, (bannerLoop - (p + 2)) & 0xFF);
  put(0xB4, 0x01);                   // mov ah, 0x01
  put(0xCD, 0x16);                   // int 16h

  // --------------------------------------------------------------------------
  // AUDIT FIX (Kehai, 2026-11-10): one disk reader for every boot medium.
  // A USB stick usually boots as a hard disk (DL >= 0x80) with a geometry the BIOS
  // invents (SeaBIOS reports 2/16/90 for a 1.44 MB image; real PCs vary), so fixed
  // 18-sector, 2-head CHS math read the wrong sectors and halted with 'E'.
  // Now: hard disks use INT 13h extensions (LBA, AH=42h) when present; everything
  // else uses CHS with the geometry INT 13h AH=08h reports (default 18/2). Reads never
  // cross a track (CHS) or a 64 KB DMA boundary. Stage 2 calls this same routine.
  // Variables: [7D90] sectors/track, [7D91] heads, [7D92] use LBA, [7DF4] CX, [7DF6] DH,
  //            [7DF8] chunk count, [7DFA] retries, [7DFC] boot drive. DAP built on the stack.
  // --------------------------------------------------------------------------
  const L = {}, fx = [];
  const lab = (n) => { L[n] = p; };
  const j8 = (op, n) => { put(op, 0); fx.push([p - 1, n, 1]); };
  const j16 = (op, n) => { put(op); put16(0); fx.push([p - 2, n, 2]); };

  // Geometry. Defaults (18 spt, 2 heads, CHS) are stored in this sector's own bytes
  // 0x190..0x192 (right after the banner), so they are already in memory at 7D90..7D92 when the BIOS loads us.
  b[0x190] = 18; b[0x191] = 2; b[0x192] = 0;
  put(0xB4, 0x08);                           // mov ah, 08h
  put(0x8A, 0x16); put16(0x7DFC);            // mov dl, [7DFC]
  put(0xCD, 0x13);                           // int 13h
  j8(0x72, 'geom_done');                     // jc geom_done
  put(0x80, 0xE1, 0x3F);                     // and cl, 3Fh
  j8(0x74, 'geom_done');                     // jz geom_done (0 sectors/track = bogus)
  put(0x88, 0x0E); put16(0x7D90);            // mov [7D90], cl
  put(0xFE, 0xC6);                           // inc dh
  put(0x88, 0x36); put16(0x7D91);            // mov [7D91], dh
  lab('geom_done');
  // INT 13h extensions (hard-disk boot only)
  put(0x8A, 0x16); put16(0x7DFC);            // mov dl, [7DFC]
  put(0x80, 0xFA, 0x80);                     // cmp dl, 80h
  j8(0x72, 'ext_done');                      // jb ext_done
  put(0xB4, 0x41);                           // mov ah, 41h
  put(0xBB); put16(0x55AA);                  // mov bx, 55AAh
  put(0xCD, 0x13);                           // int 13h
  j8(0x72, 'ext_done');                      // jc ext_done
  put(0x81, 0xFB); put16(0xAA55);            // cmp bx, AA55h
  j8(0x75, 'ext_done');                      // jne ext_done
  put(0xF6, 0xC1, 0x01);                     // test cl, 1
  j8(0x74, 'ext_done');                      // jz ext_done
  put(0xC6, 0x06); put16(0x7D92); put(1);    // mov byte [7D92], 1
  lab('ext_done');

  // Load Stage 2 (LBA 1, 1 sector) to 0000:7E00 and jump to it
  put(0xBE); put16(1);                       // mov si, 1
  put(0xBD); put16(1);                       // mov bp, 1
  put(0xBF); put16(0x07E0);                  // mov di, 07E0h
  j16(0xE8, 'read_range');                   // call read_range
  put(0xEA); put16(0x7E00); put16(0x0000);   // jmp 0000:7E00

  // read_range: SI = first LBA, BP = sector count, DI = destination segment
  lab('read_range');
  lab('rr_loop');
  put(0x85, 0xED);                           // test bp, bp
  put(0x0F); j16(0x84, 'rr_done');           // jz near rr_done
  put(0x89, 0xFB);                           // mov bx, di
  put(0x81, 0xE3); put16(0x0FFF);            // and bx, 0FFFh
  put(0xC1, 0xEB, 0x05);                     // shr bx, 5
  put(0xF7, 0xDB);                           // neg bx
  put(0x81, 0xC3); put16(128);               // add bx, 128   (sectors left before 64 KB boundary)
  put(0x89, 0xE8);                           // mov ax, bp
  put(0x39, 0xD8);                           // cmp ax, bx
  put(0x76, 0x02);                           // jbe +2
  put(0x89, 0xD8);                           // mov ax, bx
  put(0x3C, 0x7F);                           // cmp al, 127 (ax <= 128 here, so ah = 0)
  put(0x76, 0x02);                           // jbe +2
  put(0xB0, 0x7F);                           // mov al, 127 (some BIOSes reject >127 per call)
  put(0x80, 0x3E); put16(0x7D92); put(0);    // cmp byte [7D92], 0
  j8(0x75, 'rr_chunk');                      // jne rr_chunk (LBA: no track limit)
  put(0x50);                                 // push ax
  put(0x89, 0xF0);                           // mov ax, si
  put(0xF6, 0x36); put16(0x7D90);            // div byte [7D90] -> al = track, ah = sector-1
  put(0x88, 0xE1);                           // mov cl, ah
  put(0xFE, 0xC1);                           // inc cl
  put(0x30, 0xE4);                           // xor ah, ah
  put(0xF6, 0x36); put16(0x7D91);            // div byte [7D91] -> al = cyl, ah = head
  put(0x88, 0xC5);                           // mov ch, al
  put(0x89, 0x0E); put16(0x7DF4);            // mov [7DF4], cx
  put(0x88, 0x26); put16(0x7DF6);            // mov [7DF6], ah (head)
  put(0x8A, 0x1E); put16(0x7D90);            // mov bl, [7D90]
  put(0x28, 0xCB);                           // sub bl, cl
  put(0xFE, 0xC3);                           // inc bl
  put(0x30, 0xFF);                           // xor bh, bh   (sectors left on this track)
  put(0x58);                                 // pop ax
  put(0x39, 0xD8);                           // cmp ax, bx
  put(0x76, 0x02);                           // jbe +2
  put(0x89, 0xD8);                           // mov ax, bx
  lab('rr_chunk');
  put(0xA3); put16(0x7DF8);                  // mov [7DF8], ax
  put(0xC6, 0x06); put16(0x7DFA); put(3);    // mov byte [7DFA], 3
  lab('rr_retry');
  put(0x8A, 0x16); put16(0x7DFC);            // mov dl, [7DFC]
  put(0x80, 0x3E); put16(0x7D92); put(0);    // cmp byte [7D92], 0
  j8(0x74, 'rr_chs');                        // je rr_chs
  // Disk address packet built on the stack (SS = DS = 0): size 16, count, 0000:offset, LBA
  put(0x56);                                 // push si (keep LBA)
  put(0x31, 0xC0);                           // xor ax, ax
  put(0x50, 0x50, 0x50);                     // push ax x3 (LBA bits 16..63)
  put(0x56);                                 // push si (LBA bits 0..15)
  put(0x57);                                 // push di (segment)
  put(0x50);                                 // push ax (offset 0)
  put(0xFF, 0x36); put16(0x7DF8);            // push word [7DF8] (count)
  put(0x6A, 0x10);                           // push 10h (size 16, reserved 0)
  put(0x89, 0xE6);                           // mov si, sp
  put(0xB4, 0x42);                           // mov ah, 42h
  put(0xCD, 0x13);                           // int 13h
  put(0x5B, 0x5B, 0x5B, 0x5B, 0x5B, 0x5B, 0x5B, 0x5B); // pop bx x8 (drop the packet; keeps CF)
  put(0x5E);                                 // pop si
  j8(0xEB, 'rr_check');                      // jmp rr_check
  lab('rr_chs');
  put(0x8E, 0xC7);                           // mov es, di
  put(0x31, 0xDB);                           // xor bx, bx
  put(0x8B, 0x0E); put16(0x7DF4);            // mov cx, [7DF4]
  put(0x8A, 0x36); put16(0x7DF6);            // mov dh, [7DF6]
  put(0xA0); put16(0x7DF8);                  // mov al, [7DF8]
  put(0xB4, 0x02);                           // mov ah, 02h
  put(0xCD, 0x13);                           // int 13h
  lab('rr_check');
  j8(0x73, 'rr_ok');                         // jnc rr_ok
  put(0x31, 0xC0);                           // xor ax, ax
  put(0x8A, 0x16); put16(0x7DFC);            // mov dl, [7DFC]
  put(0xCD, 0x13);                           // int 13h (reset)
  put(0xFE, 0x0E); put16(0x7DFA);            // dec byte [7DFA]
  j8(0x75, 'rr_retry');                      // jnz rr_retry
  put(0xB8); put16(0x0E45);                  // mov ax, 0E45h ('E')
  put(0x31, 0xDB);                           // xor bx, bx
  put(0xCD, 0x10);                           // int 10h
  put(0xFA, 0xF4);                           // cli; hlt
  lab('rr_ok');
  put(0xA1); put16(0x7DF8);                  // mov ax, [7DF8]
  put(0x01, 0xC6);                           // add si, ax
  put(0x29, 0xC5);                           // sub bp, ax
  put(0xC1, 0xE0, 0x05);                     // shl ax, 5
  put(0x01, 0xC7);                           // add di, ax
  j16(0xE9, 'rr_loop');                      // jmp near rr_loop
  lab('rr_done');
  put(0xC3);                                 // ret

  for (const [at, n, size] of fx) {
    const rel = L[n] - (at + size);
    if (size === 1) {
      if (rel < -128 || rel > 127) throw new Error(`Stage 1 short jump to ${n} out of range (${rel})`);
      b[at] = rel & 0xFF;
    } else {
      dv.setInt16(at, rel, true);
    }
  }
  if (p > 0x180) throw new Error(`Stage 1 code overflows into the boot banner (${p} > 0x180)`);
  b.readRangeAddr = 0x7C00 + L.read_range;

  // Offset 0x180 (phys 0x7D80): 16-byte Boot Banner String
  for (let i = 0; i < 16; i++) {
    b[0x180 + i] = i < customBanner.length ? (customBanner.charCodeAt(i) & 0xFF) : 0;
  }

  // AUDIT FIX (Kehai, 2026-11-10): the GDT used to live at 0x1A0..0x1CF, on top of the MBR
  // partition table (entry 1 status byte was 0xCF). Older BIOSes reject a USB stick whose
  // partition status bytes aren't 0x00/0x80, so the table is now all zeros (a classic
  // "superfloppy" with a FAT12 BPB) and the GDT lives in Stage 2 at 0x7F00.
  // Boot sector signature 0xAA55
  b[510] = 0x55;
  b[511] = 0xAA;
  return b;
}


// KEHAI REAL-HW FIX 3 (2026-11-14): put the 8259s and PIT back the way the BIOS left them
// (vectors 0x08/0x70, saved masks, 18.2 Hz) before re-entering BIOS INT 13h, and restore
// SpiralOS's setup (0x20/0x28, IRQ0 only, 0x2E9B) afterwards. Interrupts must be off (cli).
function emitPicPit(x, toBios) {
  x.movRegImm32(R.EAX, 0x11); x.outImm8Al(0x20); x.outImm8Al(0xA0);
  x.movRegImm32(R.EAX, toBios ? 0x08 : 0x20); x.outImm8Al(0x21);
  x.movRegImm32(R.EAX, toBios ? 0x70 : 0x28); x.outImm8Al(0xA1);
  x.movRegImm32(R.EAX, 0x04); x.outImm8Al(0x21);
  x.movRegImm32(R.EAX, 0x02); x.outImm8Al(0xA1);
  x.movRegImm32(R.EAX, 0x01); x.outImm8Al(0x21); x.outImm8Al(0xA1);
  if (toBios) {
    x.xorRegReg32(R.ECX, R.ECX); x.movRegMem32(R.EAX, R.ECX, 0x57E8); x.outImm8Al(0x21);
    x.xorRegReg32(R.ECX, R.ECX); x.movRegMem32(R.EAX, R.ECX, 0x57EC); x.outImm8Al(0xA1);
    x.movRegImm32(R.EAX, 0x36); x.outImm8Al(0x43);
    x.movRegImm32(R.EAX, 0x00); x.outImm8Al(0x40); x.outImm8Al(0x40);
  } else {
    x.movRegImm32(R.EAX, 0xFE); x.outImm8Al(0x21);
    x.movRegImm32(R.EAX, 0xFF); x.outImm8Al(0xA1);
    x.movRegImm32(R.EAX, 0x36); x.outImm8Al(0x43);
    x.movRegImm32(R.EAX, 0x9B); x.outImm8Al(0x40);
    x.movRegImm32(R.EAX, 0x2E); x.outImm8Al(0x40);
  }
}

function buildStage2Loader(pmBiosWriteRetAddr, readRangeAddr = buildBootSector().readRangeAddr, pmBiosRead2RetAddr = 0x00008000, rmProbeRamAddr = 0x00008000, rmDisk2Addr = 0x00008000, opts = {}) {
  const b = new Uint8Array(512);
  const dv = new DataView(b.buffer);
  let p = 0;
  const put = (...arr) => { for (const v of arr) b[p++] = v & 0xFF; };
  const put16 = (v) => { b[p++] = v & 0xFF; b[p++] = (v >>> 8) & 0xFF; };
  const put32 = (v) => {
    b[p++] = v & 0xFF; b[p++] = (v >>> 8) & 0xFF;
    b[p++] = (v >>> 16) & 0xFF; b[p++] = (v >>> 24) & 0xFF;
  };

  // Stage 2 entry at 0x7E00:
  // 1. Load 32-bit Protected Mode Core: Sectors 2..31 (SI=2, BP=30) to ES=0x0800 (phys 0x00008000)
  put(0xBE); put16(2);               // mov si, 2
  put(0xBD); put16(30);              // mov bp, 30
  put(0xBF); put16(0x0800);          // mov di, 0x0800
  const call1Pos = p;
  put(0xE8); put16(0);               // call rm_read_lba_range (patched below)

  // 2. Load 480 KB Unified Image: Sectors 0..959 (SI=0, BP=960) to ES=0x1000 (phys 0x00010000..0x00087FFF)
  put(0x31, 0xF6);                   // xor si, si
  put(0xBD); put16(960);             // mov bp, 960
  put(0xBF); put16(0x1000);          // mov di, 0x1000
  const call2Pos = p;
  put(0xE8); put16(0);               // call rm_read_lba_range (patched below)

  // 3. Query VBE ModeInfoBlock into 0000:5000 for 0x0112; if bpp != 32, try 0x0142; if 0x0142 fails, re-query 0x0112 (24-bpp)
  put(0x31, 0xC0);                   // xor ax, ax
  put(0x8E, 0xC0);                   // mov es, ax
  put(0xB9); put16(0x0112);          // mov cx, 0x0112
  put(0xBF); put16(0x5000);          // mov di, 0x5000
  put(0xB8); put16(0x4F01);          // mov ax, 0x4F01
  put(0xCD, 0x10);                   // int 10h
  put(0x80, 0x3E); put16(0x5019); put(32); // cmp byte [0x5019], 32
  const jeMode1 = p + 1;
  put(0x74, 0);                      // je vbe_set_mode
  put(0xB9); put16(0x0142);          // mov cx, 0x0142
  put(0xB8); put16(0x4F01);          // mov ax, 0x4F01
  put(0xCD, 0x10);                   // int 10h
  put(0x3D); put16(0x004F);          // cmp ax, 0x004F
  const jeMode2 = p + 1;
  put(0x74, 0);                      // je vbe_set_mode
  put(0xB9); put16(0x0112);          // mov cx, 0x0112 (fallback to 24-bpp 0x0112)
  put(0xB8); put16(0x4F01);          // mov ax, 0x4F01
  put(0xCD, 0x10);                   // int 10h
  // vbe_set_mode:
  b[jeMode1] = (p - (jeMode1 + 1)) & 0xFF;
  b[jeMode2] = (p - (jeMode2 + 1)) & 0xFF;
  put(0xB8); put16(0x4F02);          // mov ax, 0x4F02
  put(0x89, 0xCB);                   // mov bx, cx
  put(0x80, 0xCF, 0x40);             // or bh, 0x40 (LFB)
  put(0xCD, 0x10);                   // int 10h

  // 4. Enable A20 line (Port 0x92)
  put(0xFA);                         // cli
  put(0xE4, 0x92);                   // in al, 0x92
  put(0x0C, 0x02);                   // or al, 2
  put(0xE6, 0x92);                   // out 0x92, al

  // 5. Build 4MB PSE Page Directory at 0x00006000
  put(0x31, 0xC0);                   // xor ax, ax
  put(0x8E, 0xC0);                   // mov es, ax
  put(0xBF); put16(0x6000);          // mov di, 0x6000
  put(0xB9); put16(2048);            // mov cx, 2048 words
  put(0xFC);                         // cld
  put(0xF3, 0xAB);                   // rep stosw
  // Map first 8 MB identity (entries 0..1); pm_entry maps verified E820 pages up to 256 MB
  put(0x66, 0xB8); put32(0x00000083);// mov eax, 0x83 (Present | RW | PS)
  put(0xBF); put16(0x6000);
  put(0xB9); put16(2);
  const pdeLoop = p;
  put(0x66, 0x26, 0x89, 0x05);
  put(0x66, 0x05); put32(0x00400000);
  put(0x83, 0xC7, 0x04);
  put(0xE2, (pdeLoop - (p + 2)) & 0xFF);
  // Map VBE LFB PhysBasePtr ([0x5028]) at virtual 0xE0000000 (PDE 896 at 0x6E00)
  put(0xBF); put16(0x6E00);
  put(0x66, 0xA1); put16(0x5028);    // mov eax, [0x5028]
  put(0x66, 0x25); put32(0xFFC00000);
  put(0x0C, 0x83);
  put(0x66, 0x26, 0x89, 0x05);
  put(0x66, 0x05); put32(0x00400000);
  put(0x66, 0x26, 0x89, 0x45, 0x04);

  // 6. Load GDTR, CR3, CR4.PSE, CR0 (PG | PE), and far jump to 0x0008:0x00008000
  put(0x0F, 0x01, 0x16); put16(0x7F00); // lgdt [0x7F00]
  put(0x66, 0xB8); put32(0x00006000);   // mov eax, 0x6000
  put(0x0F, 0x22, 0xD8);                // mov cr3, eax
  put(0x0F, 0x20, 0xE0);                // mov eax, cr4
  put(0x66, 0x83, 0xC8, 0x10);          // or eax, 0x10 (PSE)
  put(0x0F, 0x22, 0xE0);                // mov cr4, eax
  put(0x0F, 0x20, 0xC0);                // mov eax, cr0
  put(0x66, 0x0D); put32(0x80000001);   // or eax, 0x80000001 (PG | PE)
  put(0x0F, 0x22, 0xC0);                // mov cr0, eax
  put(0x66, 0xEA); put32(0x00008000); put16(0x0008);

  // AUDIT FIX (Kehai, 2026-11-10): both loads above call Stage 1's read_range, which
  // handles LBA/CHS, BIOS-reported geometry, track and 64 KB DMA boundaries.
  dv.setInt16(call1Pos + 1, (readRangeAddr - 0x7E00) - (call1Pos + 3), true);
  dv.setInt16(call2Pos + 1, (readRangeAddr - 0x7E00) - (call2Pos + 3), true);

  if (p > 0x00C5) throw new Error(`Stage 2 entry overflows into Read2 Thunk (${p} > 0x00C5)`);
  // Offset 0x00C5 (phys 0x7EC5): Real-Mode Batch-2 Read Thunk (loads Sectors 960..1919 = 480 KB to 0x00010000)
  p = 0x00C5;
  put(0xB8); put16(0x0020);          // mov ax, 0x0020 (16-bit data seg, base 0)
  put(0x8E, 0xD8);                   // mov ds, ax
  put(0x66, 0xB8); put32(0x00000010);// mov eax, 0x10 (clear PE)
  put(0x0F, 0x22, 0xC0);             // mov cr0, eax
  const realRd2Entry = 0x7E00 + p + 5;
  put(0xEA); put16(realRd2Entry); put16(0x0000); // jmp 0x0000:realRd2Entry
  put(0x31, 0xC0);                   // xor ax, ax
  put(0x8E, 0xD8);                   // mov ds, ax
  put(0x8E, 0xC0);                   // mov es, ax
  put(0x8E, 0xD0);                   // mov ss, ax
  put(0xBC); put16(0x7C00);          // mov sp, 0x7C00
  const callProbePos = p;
  put(0xE8); put16(0);               // call rm_probe_ram
  dv.setInt16(callProbePos + 1, (rmProbeRamAddr - 0x7E00) - (callProbePos + 3), true);
  // SI=960, BP=960, DI=0x1000 set by rm_probe_ram
  const callRd2Pos = p;
  put(0xE8); put16(0);               // call read_range
  dv.setInt16(callRd2Pos + 1, (readRangeAddr - 0x7E00) - (callRd2Pos + 3), true);
  put(0x66, 0xB8); put32(0x80000011);// mov eax, 0x80000011 (PG | PE | ET)
  put(0x0F, 0x22, 0xC0);             // mov cr0, eax
  put(0x66, 0xEA); put32(pmBiosRead2RetAddr >>> 0); put16(0x0008);
  if (p > 0x0100) throw new Error(`Stage 2 loader overflows into the GDT (${p} > 0x100)`);

  // Offset 0x100 (phys 0x7F00): GDTR (6 bytes) + 5 GDT descriptors at 0x7F08 (40 bytes)
  dv.setUint16(0x100, 39, true);
  dv.setUint32(0x102, 0x00007F08, true);
  // 0x08: 32-bit Code segment (base 0, limit 4GB, 0x9A, 0xCF)
  b.set([0xFF, 0xFF, 0x00, 0x00, 0x00, 0x9A, 0xCF, 0x00], 0x108 + 8);
  // 0x10: 32-bit Data segment (base 0, limit 4GB, 0x92, 0xCF)
  b.set([0xFF, 0xFF, 0x00, 0x00, 0x00, 0x92, 0xCF, 0x00], 0x108 + 16);
  // 0x18: 16-bit Code segment (base 0, limit 64KB, 0x9A, 0x00)
  b.set([0xFF, 0xFF, 0x00, 0x00, 0x00, 0x9A, 0x00, 0x00], 0x108 + 24);
  // 0x20: 16-bit Data segment (base 0, limit 64KB, 0x92, 0x00)
  b.set([0xFF, 0xFF, 0x00, 0x00, 0x00, 0x92, 0x00, 0x00], 0x108 + 32);

  // Offset 0x0130 (phys 0x7F30): Real-Mode Dispatch to rm_disk2_io (handles 0xFFFF APM & 0xFFFE Disk2)
  p = 0x0130;
  const apmHelperOff = p;
  const callD2Pos = p;
  put(0xE8); put16(0);               // call rm_disk2_io
  dv.setInt16(callD2Pos + 1, (rmDisk2Addr - 0x7E00) - (callD2Pos + 3), true);
  const jmpD2Done = p;
  put(0xE9); put16(0);               // jmp near wr_ok

  // --------------------------------------------------------------------------
  // Offset 0x0140 (phys 0x7F40): Real-Mode BIOS INT 13h AH=03h Write & APM Thunk
  // Entered via jmp 0x0018:0x7F40 with CR0.PG=0, sector in 0x5800, LBA in [0x57FC]
  // --------------------------------------------------------------------------
  p = 0x0140;
  // DS/ES/SS/FS/GS already loaded with 0x0020 (16-bit B=0) and IDTR=[0x7FF0] in bios_sync_loop
  put(0x66, 0xB8); put32(0x00000010);// mov eax, 0x10 (clear PE cleanly)
  put(0x0F, 0x22, 0xC0);             // mov cr0, eax
  const realEntryOff = 0x7E00 + p + 5;
  put(0xEA); put16(realEntryOff); put16(0x0000); // jmp 0x0000:realEntryOff

  // Now in 16-bit Real Mode!
  put(0x31, 0xC0);                   // xor ax, ax
  put(0x8E, 0xD8);                   // mov ds, ax
  put(0x8E, 0xC0);                   // mov es, ax
  put(0x8E, 0xD0);                   // mov ss, ax
  put(0xBC); put16(0x7C00);          // mov sp, 0x7C00
  put(0x0F, 0x01, 0x1E); put16(0x7FF0); // lidt [0x7FF0] (Real-Mode IVT)

  // Compute CHS from LBA at [0x57FC] (0xFFFF = APM power-off, 0xFFFE = Disk2 INT 13h ext)
  put(0xA1); put16(0x57FC);          // mov ax, [0x57FC]
  put(0x3D); put16(0xFFFE);          // cmp ax, 0xFFFE
  put(0x73, (apmHelperOff - (p + 2)) & 0xFF); // jae apmHelperOff
  put(0x8A, 0x1E); put16(0x7D90);    // mov bl, [0x7D90] (sectors per track, saved by stage 1)
  put(0xF6, 0xF3);                   // div bl -> al = track, ah = sect - 1
  put(0x88, 0xE1);                   // mov cl, ah
  put(0xFE, 0xC1);                   // inc cl
  put(0x30, 0xE4);                   // xor ah, ah
  put(0xF6, 0x36); put16(0x7D91);    // div byte [0x7D91] -> al = cyl, ah = head
  put(0x88, 0xE6);                   // mov dh, ah
  put(0x88, 0xC5);                   // mov ch, al

  put(0xBE); put16(3);               // mov si, 3 retries
  const wrRetry = p;
  // AUDIT FIX (Kehai, 2026-11-10): on a hard-disk/USB boot with INT 13h extensions, write by
  // LBA (AH=43h) like Stage 1 reads; BIOS-invented CHS geometry would hit the wrong sector.
  put(0x8A, 0x16); put16(0x7DFC);    // mov dl, [0x7DFC]
  put(0x80, 0x3E); put16(0x7D92); put(0); // cmp byte [0x7D92], 0
  const jeChsWr = p + 1;
  put(0x74, 0);                      // je chs_write
  put(0x56);                         // push si (retry counter)
  put(0x31, 0xC0);                   // xor ax, ax
  put(0x50, 0x50, 0x50);             // push ax x3 (LBA bits 16..63)
  put(0xFF, 0x36); put16(0x57FC);    // push word [0x57FC] (LBA bits 0..15)
  put(0x50);                         // push ax (segment 0)
  put(0x68); put16(0x5800);          // push 0x5800 (offset)
  put(0x6A, 0x01);                   // push 1 (count)
  put(0x6A, 0x10);                   // push 0x10 (packet size)
  put(0x89, 0xE6);                   // mov si, sp
  put(0xB4, 0x43);                   // mov ah, 0x43 (extended write, AL=0 no verify)
  put(0xCD, 0x13);                   // int 13h
  put(0xBC); put16(0x7BFE);          // mov sp, 0x7BFE (pop 8-word DAP without touching CF)
  put(0x5E);                         // pop si
  const jmpWrCheck = p + 1;
  put(0xEB, 0);                      // jmp wr_check
  b[jeChsWr] = (p - (jeChsWr + 1)) & 0xFF;
  // chs_write:
  put(0xBB); put16(0x5800);          // mov bx, 0x5800
  put(0xB8); put16(0x0301);          // mov ax, 0x0301 (write 1 sector)
  put(0xCD, 0x13);                   // int 13h
  b[jmpWrCheck] = (p - (jmpWrCheck + 1)) & 0xFF;
  // wr_check:
  const jncWrPos = p + 1;
  put(0x73, 0);                      // jnc wr_ok
  put(0x31, 0xC0);                   // xor ax, ax
  put(0x8A, 0x16); put16(0x7DFC);    // mov dl, [0x7DFC]
  put(0xCD, 0x13);                   // int 13h
  put(0x4E);                         // dec si
  put(0x75, (wrRetry - (p + 2)) & 0xFF);
  const jmpWrFailPos = p + 1;
  put(0xEB, 0);                      // jmp wr_ok
  // wr_ok: return to 32-bit Protected Mode with Paging!
  dv.setInt16(jmpD2Done + 1, p - (jmpD2Done + 3), true);
  b[jncWrPos] = (p - (jncWrPos + 1)) & 0xFF;
  b[jmpWrFailPos] = (p - (jmpWrFailPos + 1)) & 0xFF;
  put(0xFA);                            // cli (BIOS INT 13h/15h may have re-enabled IF!)
  put(0x0F, 0x01, 0x16); put16(0x7F00); // lgdt [0x7F00]
  put(0x66, 0xB8); put32(0x00006000);   // mov eax, 0x6000
  put(0x0F, 0x22, 0xD8);                // mov cr3, eax
  put(0x66, 0xB8); put32(0x80000011);   // mov eax, 0x80000011 (PG | PE | ET)
  put(0x0F, 0x22, 0xC0);                // mov cr0, eax
  const retAddr = opts.brokenShutdownReturn ? 0x00008000 : (pmBiosWriteRetAddr >>> 0);
  put(0x66, 0xEA); put32(retAddr); put16(0x0008);

  if (p > 0x1F0) throw new Error(`BIOS write thunk overflows into the IDTRs (${p} > 0x1F0)`);
  // Offset 0x01F0 (phys 0x7FF0): Real-Mode IDTR (limit 0x03FF, base 0x00000000)
  dv.setUint16(0x1F0, 0x03FF, true);
  dv.setUint32(0x1F2, 0x00000000, true);
  // Offset 0x01F8 (phys 0x7FF8): Protected-Mode IDTR (limit 383, base 0x00006800)
  dv.setUint16(0x1F8, 383, true);
  dv.setUint32(0x1FA, 0x00006800, true);

  return b;
}

function buildProtectedModeCore(opts = {}) {
  const x = new X86Builder(0x00008000);
  x.orRegImm32 = (reg, imm) => { x.u8(0x81); x.modrm(3, 1, reg); x.u32(imm); };

  // Scratch RAM addresses at 0x00007000:
  const ADDR_VM_FP       = 0x7000;
  const ADDR_VM_CSP      = 0x7004;
  const ADDR_VM_ICNT     = 0x7008;
  const ADDR_MOUSE_X     = 0x700C;
  const ADDR_MOUSE_Y     = 0x7010;
  const ADDR_MOUSE_BTN   = 0x7014;
  const ADDR_MOUSE_STAGE = 0x7018;
  const ADDR_MOUSE_B0    = 0x701C;
  const ADDR_MOUSE_B1    = 0x7020;
  const ADDR_KEY_MODS    = 0x7024;
  const ADDR_KEY_EVENT   = 0x7028;
  const ADDR_HAS_SNET    = 0x7030;
  const ADDR_HAS_FDC     = 0x7034;
  const ADDR_HAS_SB16    = 0x703C;
  const ADDR_VM_RAM_SIZE = 0x7038;

  // ==========================================================================
  // 1. 32-Bit Protected Mode Entry (0x00008000)
  // ==========================================================================
  x.label("pm_entry");
  x.cli();
  x.cld();
  x.movRegImm32(R.EAX, 0x0010);
  x.u8(0x8E); x.u8(0xD8); // mov ds, ax
  x.u8(0x8E); x.u8(0xC0); // mov es, ax
  x.u8(0x8E); x.u8(0xD0); // mov ss, ax
  x.u8(0x8E); x.u8(0xE0); // mov fs, ax
  x.u8(0x8E); x.u8(0xE8); // mov gs, ax
  x.movRegImm32(R.ESP, 0x00098000);

  // KEHAI REAL-HW FIX (2026-11-14): read Batch 2 through the BIOS *before* the PIC/PIT are
  // reprogrammed. The BIOS's real-mode INT 13h needs the 8259 at its power-on vectors
  // (0x08/0x70) with IRQs unmasked; after the remap below, a real BIOS hangs (black screen).
  // Copy Batch 1 (Sectors 0..959, 480 KB) from 0x00010000 to 0x00400000 (vmRam[0x200000..0x277FFF])
  x.movRegImm32(R.ESI, 0x00010000);
  x.movRegImm32(R.EDI, 0x00400000);
  x.movRegImm32(R.ECX, (480 * 1024) >>> 2);
  x.repMovsd();

  // Batch-2 (Sectors 960..1919) then Batch-3 (Sectors 1920..2879) via Real-Mode Read Thunk
  x.xorRegReg32(R.EAX, R.EAX);
  x.movMemReg32(R.EAX, 0x51EC, R.EAX);
  x.label("pm_bios_read_batch_go");
  x.cli();
  // KEHAI REAL-HW FIX 2: a real CPU keeps each segment's cached attributes across the drop to
  // real mode. SS still held the 32-bit data descriptor (B=1), so the BIOS's stack ran on ESP
  // (0x97C00) while its BP-relative frames addressed SS:BP (0x7Bxx) -> INT 13h crashed.
  // Load 16-bit (B=0, 64 KB) selectors into every data segment, zero ESP's high half, and point
  // IDTR at the real-mode IVT before leaving protected mode. Emulators reset these; silicon doesn't.
  x.movRegImm32(R.EAX, 0x0020);
  x.u8(0x8E); x.u8(0xD8); // mov ds, ax
  x.u8(0x8E); x.u8(0xC0); // mov es, ax
  x.u8(0x8E); x.u8(0xD0); // mov ss, ax
  x.u8(0x8E); x.u8(0xE0); // mov fs, ax
  x.u8(0x8E); x.u8(0xE8); // mov gs, ax
  x.movRegImm32(R.ESP, 0x00007C00);
  x.u8(0x0F); x.u8(0x01); x.u8(0x1D); x.u32(0x00007FF0); // lidt [0x7FF0] (real-mode IVT)
  x.movRegImm32(R.EAX, 0x00000011);
  x.u8(0x0F); x.u8(0x22); x.u8(0xC0);
  x.u8(0xEA); x.u32(0x00007EC5); x.u16(0x0018);
  x.label("pm_bios_read2_ret");
  x.movRegImm32(R.EAX, 0x0010);
  x.u8(0x8E); x.u8(0xD8);
  x.u8(0x8E); x.u8(0xC0);
  x.u8(0x8E); x.u8(0xD0);
  x.u8(0x8E); x.u8(0xE0);
  x.u8(0x8E); x.u8(0xE8);
  x.movRegImm32(R.ESP, 0x00098000);
  x.u8(0x0F); x.u8(0x01); x.u8(0x1D); x.u32(0x00007FF8);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, 0x51EC);
  x.cmpRegImm32(R.EAX, 0);
  x.jneLabel("pm_copy_batch3");
  x.movRegImm32(R.ESI, 0x00010000);
  x.movRegImm32(R.EDI, 0x00478000);
  x.movRegImm32(R.ECX, (480 * 1024) >>> 2);
  x.repMovsd();
  x.xorRegReg32(R.EDX, R.EDX);
  x.movMemImm32(R.EDX, 0x51EC, 1);
  x.jmpLabel("pm_bios_read_batch_go");
  x.label("pm_copy_batch3");
  x.movRegImm32(R.ESI, 0x00010000);
  x.movRegImm32(R.EDI, 0x004F0000);
  x.movRegImm32(R.ECX, (480 * 1024) >>> 2);
  x.repMovsd();

  // 1.6: Build contiguous 4 MB PSE Page Directory from E820/E801/88h map at 0x5200 (count at [0x51FC]).
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, 0x5028);       // VBE PhysBasePtr
  x.andRegImm32(R.EAX, 0xFFC00000);
  x.movMemReg32(R.EDX, 0x51F0, R.EAX);       // [0x51F0] = vbe_4m_base
  x.movMemImm32(R.EDX, 0x51F4, 2);           // [0x51F4] = next_pde (starts at 2 = 8 MB)
  x.movRegImm32(R.EBX, 0x00800000);          // EBX = candidate physical chunk P (starts at 8 MB)

  x.label("e820_chunk_lp");
  x.cmpRegImm32(R.EBX, 0x10000000);          // up to 256 MB (64 PDEs)
  x.jgeLabel("e820_map_done");

  // Skip VBE LFB range [vbe_base, vbe_base + 8 MB)
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, 0x51F0);
  x.cmpRegReg32(R.EBX, R.EAX);
  x.jeLabel("e820_next_chunk");
  x.addRegImm32(R.EAX, 0x00400000);
  x.cmpRegReg32(R.EBX, R.EAX);
  x.jeLabel("e820_next_chunk");

  x.movMemImm32(R.EDX, 0x51E8, 0);
  x.movMemImm32(R.EDX, 0x51EC, 0);
  x.movRegMem32(R.ECX, R.EDX, 0x51FC);
  x.movRegImm32(R.ESI, 0x00005200);
  x.cmpRegImm32(R.ECX, 0);
  x.jleLabel("e820_scan_done");

  x.label("e820_ent_lp");
  x.movRegMem32(R.EAX, R.ESI, 4);            // baseHi
  x.cmpRegImm32(R.EAX, 0);
  x.jneLabel("e820_ent_next");
  x.movRegMem32(R.EAX, R.ESI, 0);            // EAX = baseLo
  x.movRegMem32(R.EDI, R.ESI, 8);            // EDI = lenLo
  x.movRegMem32(R.EDX, R.ESI, 12);           // EDX = lenHi
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("e820_sat_end");
  x.addRegReg32(R.EDI, R.EAX);               // EDI = baseLo + lenLo
  x.cmpRegReg32(R.EDI, R.EAX);
  x.jbLabel("e820_sat_end");
  x.jmpLabel("e820_end_ok");
  x.label("e820_sat_end");
  x.movRegImm32(R.EDI, 0xFFFFFFFF);
  x.label("e820_end_ok");
  x.movRegMem32(R.EDX, R.ESI, 16);
  x.cmpRegImm32(R.EDX, 1);
  x.jneLabel("e820_ent_non_usable");
  x.cmpRegReg32(R.EAX, R.EBX);
  x.jaLabel("e820_ent_next");
  x.movRegReg32(R.EDX, R.EBX);
  x.addRegImm32(R.EDX, 0x00400000);
  x.cmpRegReg32(R.EDI, R.EDX);
  x.jbLabel("e820_ent_next");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movMemImm32(R.EDX, 0x51E8, 1);
  x.jmpLabel("e820_ent_next");

  x.label("e820_ent_non_usable");
  x.cmpRegReg32(R.EDI, R.EBX);
  x.jleLabel("e820_ent_next");
  x.movRegReg32(R.EDX, R.EBX);
  x.addRegImm32(R.EDX, 0x00400000);
  x.cmpRegReg32(R.EAX, R.EDX);
  x.jgeLabel("e820_ent_next");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movMemImm32(R.EDX, 0x51EC, 1);

  x.label("e820_ent_next");
  x.addRegImm32(R.ESI, 20);
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("e820_ent_lp");

  x.label("e820_scan_done");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, 0x51E8);
  x.cmpRegImm32(R.EAX, 1);
  x.jneLabel("e820_next_chunk");
  x.movRegMem32(R.EAX, R.EDX, 0x51EC);
  x.cmpRegImm32(R.EAX, 0);
  x.jneLabel("e820_next_chunk");

  x.movRegMem32(R.ECX, R.EDX, 0x51F4);
  x.movRegReg32(R.EAX, R.EBX);
  x.orRegImm32(R.EAX, 0x00000083);
  x.movRegImm32(R.EDI, 0x00006000);
  x.movSibReg32(R.EDI, R.ECX, 2, 0, R.EAX);
  x.addRegImm32(R.ECX, 1);
  x.movMemReg32(R.EDX, 0x51F4, R.ECX);

  x.label("e820_next_chunk");
  x.addRegImm32(R.EBX, 0x00400000);
  x.jmpLabel("e820_chunk_lp");

  x.label("e820_map_done");
  x.movRegImm32(R.EAX, 0x00006000);
  x.u8(0x0F); x.u8(0x22); x.u8(0xD8);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, 0x51F4);
  x.shlRegImm(R.EAX, 22);
  x.subRegImm32(R.EAX, 0x00200000);
  x.movMemReg32(R.EDX, ADDR_VM_RAM_SIZE, R.EAX);


  // 1.2 F2: Proper 8042 PS/2 mouse init handshake (replacing spiralos/core/core_x86.js:506-515)
  x.inAlImm8(0x64);
  x.andRegImm32(R.EAX, 0xFF);
  x.cmpRegImm32(R.EAX, 0xFF);
  x.jeLabel("skip_ps2_init");

  // 4. Flush any stale output bytes first (bounded to 64 reads)
  x.movRegImm32(R.ECX, 64);
  x.label("ps2_flush_lp");
  x.inAlImm8(0x64);
  x.andRegImm32(R.EAX, 1);
  x.jeLabel("ps2_flush_done");
  x.inAlImm8(0x60);
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("ps2_flush_lp");
  x.label("ps2_flush_done");

  // Enable auxiliary port (0xA8)
  x.movRegImm32(R.EBX, 0xA8);
  x.callLabel("ps2_out_64");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("skip_ps2_init");

  // 5. Read controller command byte (0x20), set aux-enable bits & clear aux-clock-disable bit, write back (0x60)
  x.movRegImm32(R.EBX, 0x20);
  x.callLabel("ps2_out_64");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("skip_ps2_init");
  x.callLabel("ps2_in_60");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("skip_ps2_init");
  x.orRegImm32(R.EAX, 0x03);
  x.andRegImm32(R.EAX, 0xCF);
  x.movRegReg32(R.ESI, R.EAX);

  x.movRegImm32(R.EBX, 0x60);
  x.callLabel("ps2_out_64");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("skip_ps2_init");
  x.movRegReg32(R.EBX, R.ESI);
  x.callLabel("ps2_out_60");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("skip_ps2_init");

  // 6. Reset the mouse (0xD4, 0xFF). Expect 0xFA then 0xAA, then optionally ID byte 0x00.
  // 1.6 USB-Legacy Fix: if 0xFF reset fails/times out on BIOS USB-to-PS/2 legacy emulation,
  // still fall through to 0xF6 (Set Defaults -> 3-byte mode) and 0xF4 (Enable Streaming)!
  x.movRegImm32(R.ESI, 0xFF);
  x.callLabel("ps2_mouse_cmd");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("ps2_set_defaults");
  x.callLabel("ps2_in_60_long");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("ps2_set_defaults");
  x.cmpRegImm32(R.EAX, 0xAA);
  x.jneLabel("ps2_set_defaults");
  x.callLabel("ps2_in_60");

  // 7. Set defaults (0xF6), then enable streaming (0xF4), checking for 0xFA ACK each time.
  x.label("ps2_set_defaults");
  x.movRegImm32(R.ESI, 0xF6);
  x.callLabel("ps2_mouse_cmd");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("skip_ps2_init");

  x.movRegImm32(R.ESI, 0xF4);
  x.callLabel("ps2_mouse_cmd");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("skip_ps2_init");
  x.jmpLabel("skip_ps2_init");

  // Helper: wait for IBF clear (status bit 1 == 0) then write BL to 0x64
  x.label("ps2_out_64");
  x.movRegImm32(R.ECX, 65536); // 1.2.1 H1: was 16384
  x.label("ps2_ibf64_lp");
  x.inAlImm8(0x64);
  x.andRegImm32(R.EAX, 0xFF);
  x.cmpRegImm32(R.EAX, 0xFF);
  x.jeLabel("ps2_io_fail");
  x.andRegImm32(R.EAX, 2);
  x.jeLabel("ps2_ibf64_ok");
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("ps2_ibf64_lp");
  x.jmpLabel("ps2_io_fail");
  x.label("ps2_ibf64_ok");
  x.movRegReg32(R.EAX, R.EBX);
  x.outImm8Al(0x64);
  x.xorRegReg32(R.EDX, R.EDX);
  x.ret();

  // Helper: wait for IBF clear (status bit 1 == 0) then write BL to 0x60
  x.label("ps2_out_60");
  x.movRegImm32(R.ECX, 65536); // 1.2.1 H1: was 16384
  x.label("ps2_ibf60_lp");
  x.inAlImm8(0x64);
  x.andRegImm32(R.EAX, 0xFF);
  x.cmpRegImm32(R.EAX, 0xFF);
  x.jeLabel("ps2_io_fail");
  x.andRegImm32(R.EAX, 2);
  x.jeLabel("ps2_ibf60_ok");
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("ps2_ibf60_lp");
  x.jmpLabel("ps2_io_fail");
  x.label("ps2_ibf60_ok");
  x.movRegReg32(R.EAX, R.EBX);
  x.outImm8Al(0x60);
  x.xorRegReg32(R.EDX, R.EDX);
  x.ret();

  // 1.2.1 H1: a mouse reset (0xFF) on real hardware can take hundreds of ms to
  // report its self-test (0xAA); 16,384 status reads is only ~16 ms of real I/O.
  // Long wait (~2M status reads, roughly 2 s on real ISA/LPC-speed port I/O) for
  // the BAT result only. Emulators answer early, so this costs them nothing.
  x.label("ps2_in_60_long");
  x.movRegImm32(R.ECX, 0x200000);
  x.jmpLabel("ps2_obf_lp");

  // Helper: wait for OBF set (status bit 0 == 1) then read 0x60 into EAX
  // 1.2.1 H1: default wait raised 16,384 -> 65,536 reads (~65 ms real) so ACKs
  // inside the PS/2 spec's 25 ms response window are never cut off.
  x.label("ps2_in_60");
  x.movRegImm32(R.ECX, 65536);
  x.label("ps2_obf_lp");
  x.inAlImm8(0x64);
  x.andRegImm32(R.EAX, 0xFF);
  x.cmpRegImm32(R.EAX, 0xFF);
  x.jeLabel("ps2_io_fail");
  x.andRegImm32(R.EAX, 1);
  x.jneLabel("ps2_obf_ok");
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("ps2_obf_lp");
  x.label("ps2_io_fail");
  x.movRegImm32(R.EDX, 1);
  x.ret();
  x.label("ps2_obf_ok");
  x.xorRegReg32(R.EAX, R.EAX);
  x.inAlImm8(0x60);
  x.andRegImm32(R.EAX, 0xFF);
  x.xorRegReg32(R.EDX, R.EDX);
  x.ret();

  // Helper: send 0xD4 to 0x64, ESI to 0x60, read ACK from 0x60 and verify 0xFA
  x.label("ps2_mouse_cmd");
  x.movRegImm32(R.EBX, 0xD4);
  x.callLabel("ps2_out_64");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("ps2_mcmd_ret");
  x.movRegReg32(R.EBX, R.ESI);
  x.callLabel("ps2_out_60");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("ps2_mcmd_ret");
  x.callLabel("ps2_in_60");
  x.cmpRegImm32(R.EDX, 0);
  x.jneLabel("ps2_mcmd_ret");
  x.cmpRegImm32(R.EAX, 0xFA);
  x.jeLabel("ps2_mcmd_ret");
  x.movRegImm32(R.EDX, 1);
  x.label("ps2_mcmd_ret");
  x.ret();

  x.label("skip_ps2_init");

  // Detect StudioNet presence (port 0x02A0 == 0x4E53 'SN')
  x.xorRegReg32(R.EBX, R.EBX);
  x.movMemImm32(R.EBX, ADDR_HAS_SNET, 0);
  x.movRegImm32(R.EDX, 0x02A0);
  x.xorRegReg32(R.EAX, R.EAX);
  x.inAxDx();
  x.cmpRegImm32(R.EAX, 0x4E53);
  x.jneLabel("no_snet_card");
  x.movMemImm32(R.EBX, ADDR_HAS_SNET, 1);
  x.label("no_snet_card");

  // Detect 82077AA FDC presence (port 0x03F4 != 0xFF)
  x.movMemImm32(R.EBX, ADDR_HAS_FDC, 0);
  x.movRegImm32(R.EDX, 0x03F4);
  x.xorRegReg32(R.EAX, R.EAX);
  x.inAlDx();
  x.andRegImm32(R.EAX, 0xFF);
  x.cmpRegImm32(R.EAX, 0xFF);
  x.jeLabel("no_fdc_chip");
  x.movMemImm32(R.EBX, ADDR_HAS_FDC, 1);
  x.label("no_fdc_chip");
  // AUDIT FIX (Kehai, 2026-11-10): only save through the FDC when we booted from a floppy.
  // Booted from a USB stick or hard disk (boot drive >= 0x80, saved by Stage 1 at 0x7DFC),
  // a present-but-empty FDC would swallow every save; use the BIOS thunk on the boot drive.
  x.movRegMem32(R.EAX, R.EBX, 0x7DFC);
  x.andRegImm32(R.EAX, 0xFF);
  x.cmpRegImm32(R.EAX, 0x80);
  x.jlLabel("fdc_boot_ok");
  x.movMemImm32(R.EBX, ADDR_HAS_FDC, 0);
  x.label("fdc_boot_ok");

  // Detect Sound Blaster 16 DSP at Base 0x220 (Reset 0x226 -> Read 0x22A == 0xAA)
  x.xorRegReg32(R.EBX, R.EBX);
  x.movMemImm32(R.EBX, ADDR_HAS_SB16, 0);
  x.movRegImm32(R.EDX, 0x0226);
  x.movRegImm32(R.EAX, 1);
  x.outDxAl();
  x.movRegImm32(R.ECX, 256);
  x.label("sb16_rst_dly");
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("sb16_rst_dly");
  x.xorRegReg32(R.EAX, R.EAX);
  x.outDxAl();
  x.movRegImm32(R.EDX, 0x022E);
  x.inAlDx();
  x.andRegImm32(R.EAX, 0x80);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("no_sb16_card");
  x.movRegImm32(R.EDX, 0x022A);
  x.inAlDx();
  x.andRegImm32(R.EAX, 0xFF);
  x.cmpRegImm32(R.EAX, 0xAA);
  x.jneLabel("no_sb16_card");
  x.movMemImm32(R.EBX, ADDR_HAS_SB16, 1);
  x.movRegImm32(R.EDX, 0x022C);
  x.movRegImm32(R.EAX, 0xD1); x.outDxAl();
  x.movRegImm32(R.EAX, 0x41); x.outDxAl();
  x.movRegImm32(R.EAX, 0x56); x.outDxAl();
  x.movRegImm32(R.EAX, 0x22); x.outDxAl();
  x.label("no_sb16_card");

  // Reprogram 8259A Master & Slave PICs (vectors 0x20..0x27 and 0x28..0x2F, unmask IRQ0 timer)
  // KEHAI REAL-HW FIX 3: remember the BIOS's PIC masks so BIOS calls made after the remap
  // (FDC-less saves through INT 13h AH=03h) can run with the BIOS's own interrupt setup.
  x.movRegImm32(R.EAX, 0); x.inAlImm8(0x21);
  x.xorRegReg32(R.ECX, R.ECX); x.movMemReg32(R.ECX, 0x57E8, R.EAX);
  x.movRegImm32(R.EAX, 0); x.inAlImm8(0xA1);
  x.xorRegReg32(R.ECX, R.ECX); x.movMemReg32(R.ECX, 0x57EC, R.EAX);
  x.movRegImm32(R.EAX, 0x11); x.outImm8Al(0x20); x.outImm8Al(0xA0);
  x.movRegImm32(R.EAX, 0x20); x.outImm8Al(0x21);
  x.movRegImm32(R.EAX, 0x28); x.outImm8Al(0xA1);
  x.movRegImm32(R.EAX, 0x04); x.outImm8Al(0x21);
  x.movRegImm32(R.EAX, 0x02); x.outImm8Al(0xA1);
  x.movRegImm32(R.EAX, 0x01); x.outImm8Al(0x21); x.outImm8Al(0xA1);
  x.movRegImm32(R.EAX, 0xFE); x.outImm8Al(0x21); // unmask IRQ0 (timer)
  x.movRegImm32(R.EAX, 0xFF); x.outImm8Al(0xA1);

  // Reprogram 8254 PIT Channel 0 for 100 Hz (divisor 11931 = 0x2E9B)
  x.movRegImm32(R.EAX, 0x36); x.outImm8Al(0x43);
  x.movRegImm32(R.EAX, 0x9B); x.outImm8Al(0x40);
  x.movRegImm32(R.EAX, 0x2E); x.outImm8Al(0x40);

  // Build 48-entry Protected-Mode IDT at 0x00006800 (vectors 0x00..0x2F)
  x.movRegLabel32(R.EAX, "isr_default");
  x.movRegReg32(R.EBX, R.EAX);
  x.andRegImm32(R.EAX, 0xFFFF);
  x.orRegImm32(R.EAX, 0x00080000); // selector 0x0008 << 16 | offset_lo
  x.andRegImm32(R.EBX, 0xFFFF0000);
  x.orRegImm32(R.EBX, 0x00008E00); // 32-bit interrupt gate DPL=0, P=1
  x.movRegImm32(R.EDI, 0x00006800);
  x.movRegImm32(R.ECX, 48);
  x.label("idt_fill_loop");
  x.movMemReg32(R.EDI, 0, R.EAX);
  x.movMemReg32(R.EDI, 4, R.EBX);
  x.addRegImm32(R.EDI, 8);
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("idt_fill_loop");

  // Install IRQ0 Timer ISR at vector 0x20 (0x00006800 + 0x20*8 = 0x00006900)
  x.movRegLabel32(R.EAX, "isr_irq0_timer");
  x.movRegReg32(R.EBX, R.EAX);
  x.andRegImm32(R.EAX, 0xFFFF);
  x.orRegImm32(R.EAX, 0x00080000);
  x.andRegImm32(R.EBX, 0xFFFF0000);
  x.orRegImm32(R.EBX, 0x00008E00);
  x.movRegImm32(R.EDI, 0x00006900);
  x.movMemReg32(R.EDI, 0, R.EAX);
  x.movMemReg32(R.EDI, 4, R.EBX);

  // Entry point for warm VM reboot (when vmRam[0x200000] already holds updated image)
  x.label("vm_warm_boot");
  x.cli();
  // Clear vmRam[0x000000..0x1FFFFF] (0x00200000..0x003FFFFF)
  x.xorRegReg32(R.EAX, R.EAX);
  x.movRegImm32(R.EDI, 0x00200000);
  x.movRegImm32(R.ECX, (2 * 1024 * 1024) >>> 2);
  x.repStosd();

  // Copy 128 KB bootable SPIR bytecode from 0x00408000 (Sectors 64..319) to 0x00200000 (vmRam[0])
  x.movRegImm32(R.ESI, 0x00408000);
  x.movRegImm32(R.EDI, 0x00200000);
  x.movRegImm32(R.ECX, (128 * 1024) >>> 2);
  x.repMovsd();

  // Copy 16-byte boot banner from mounted Sector 0 offset 0x180 (0x00400180) to vmRam[0x0FFD80] (0x002FFD80)
  x.movRegImm32(R.ESI, 0x00400180);
  x.movRegImm32(R.EDI, 0x002FFD80);
  x.movRegImm32(R.ECX, 4);
  x.repMovsd();

  // Copy embedded 768B font to 0x002EF000 and 0x00291800, 1536B serif font to 0x00291000, and 768B palette to 0x002FFA00
  x.movRegLabel32(R.ESI, "embedded_font");
  x.movRegImm32(R.EDI, 0x002EF000);
  x.movRegImm32(R.ECX, 768 >>> 2);
  x.repMovsd();

  x.movRegLabel32(R.ESI, "embedded_font");
  x.movRegImm32(R.EDI, 0x00291800);
  x.movRegImm32(R.ECX, 768 >>> 2);
  x.repMovsd();

  x.movRegLabel32(R.ESI, "embedded_font_serif");
  x.movRegImm32(R.EDI, 0x00291000);
  x.movRegImm32(R.ECX, 1536 >>> 2);
  x.repMovsd();

  x.movRegLabel32(R.ESI, "embedded_palette");
  x.movRegImm32(R.EDI, 0x002FFA00);
  x.movRegImm32(R.ECX, 768 >>> 2);
  x.repMovsd();

  // Initialize VM state & scratch variables
  x.xorRegReg32(R.EBX, R.EBX);
  x.movMemImm32(R.EBX, ADDR_VM_FP,       0x00100000);
  x.movMemImm32(R.EBX, ADDR_VM_CSP,      0x00170008);
  x.movMemImm32(R.EBX, ADDR_VM_ICNT,     0);
  x.movMemImm32(R.EBX, ADDR_MOUSE_X,     160);
  x.movMemImm32(R.EBX, ADDR_MOUSE_Y,     100);
  x.movMemImm32(R.EBX, ADDR_MOUSE_BTN,   0);
  x.movMemImm32(R.EBX, ADDR_MOUSE_STAGE, 0);
  x.movMemImm32(R.EBX, ADDR_KEY_MODS,    0);
  x.movMemImm32(R.EBX, ADDR_KEY_EVENT,   0);

  // Set EBP = VM_BASE (0x00200000), EDI = VM_SP (0x00100000)
  x.movRegImm32(R.EBP, 0x00200000);
  x.movRegImm32(R.EDI, 0x00100000);

  // Write Machine ID = 2 (Hummingbird) at vmRam[0x0FFD1C], StudioNet flag at vmRam[0x0FFD30], and mouse pos
  x.movMemImm32(R.EBP, 0x0FFD1C, 2);
  x.movMemImm32(R.EBP, 0x0FFD08, 160);
  x.movMemImm32(R.EBP, 0x0FFD0C, 100);
  x.movRegMem32(R.EAX, R.EBX, ADDR_HAS_SNET);
  x.movMemReg32(R.EBP, 0x0FFD30, R.EAX);

  // Write sentinel return frame at vmRam[0x170000]: [-1, 0x00100000]
  x.movMemImm32(R.EBP, 0x170000, -1);
  x.movMemImm32(R.EBP, 0x170004, 0x00100000);

  // Check SPIR magic (0x52495053) at vmRam[0]
  x.movRegMem32(R.EAX, R.EBP, 0);
  x.cmpRegImm32(R.EAX, 0x52495053);
  x.jeLabel("has_spir_hdr");
  x.xorRegReg32(R.ESI, R.ESI); // ESI = VM_PC = 0
  x.jmpLabel("init_scheduler");
  x.label("has_spir_hdr");
  x.movRegMem32(R.ESI, R.EBP, 8); // ESI = entry_pc

  // Initialize Preemptive Task Table at 0x002FFE00..0x002FFF1F
  x.label("init_scheduler");
  x.movMemImm32(R.EBP, 0x0FFE00, 1);          // TCB[0].state = 1 (ACTIVE)
  x.movMemReg32(R.EBP, 0x0FFE04, R.ESI);      // TCB[0].vm_pc
  x.movMemReg32(R.EBP, 0x0FFE08, R.EDI);      // TCB[0].vm_sp
  x.movMemImm32(R.EBP, 0x0FFE0C, 0x00100000); // TCB[0].vm_fp
  x.movMemImm32(R.EBP, 0x0FFE10, 0x00170008); // TCB[0].vm_csp
  x.movMemImm32(R.EBP, 0x0FFF00, 0);          // cur_tid = 0
  x.movMemImm32(R.EBP, 0x0FFF04, 1);          // num_active_tids = 1
  x.movMemImm32(R.EBP, 0x0FFF14, 256);        // quantum_countdown = 256
  x.u8(0xFB);                                 // sti (enable hardware IRQ0 timer interrupts!)

  // ==========================================================================
  // 2. Main Spiral VM Fetch-Decode-Execute Loop (with IRQ0 / Quantum Preemption)
  //    EBP = VM_BASE (0x00200000), ESI = VM_PC, EDI = VM_SP
  // ==========================================================================
  x.label("vm_loop");
  x.cmpRegImm32(R.ESI, 0);
  x.jlLabel("vm_task_exit_or_halt");

  // Check hardware IRQ0 preempt_flag ([EBP + 0x0FFF0C]) or quantum_countdown ([EBP + 0x0FFF14])
  x.movRegMem32(R.EAX, R.EBP, 0x0FFF14);
  x.subRegImm32(R.EAX, 1);
  x.movMemReg32(R.EBP, 0x0FFF14, R.EAX);
  x.cmpRegImm32(R.EAX, 0);
  x.jleLabel("vm_do_preempt_check");
  x.movRegMem32(R.EAX, R.EBP, 0x0FFF0C);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("vm_no_preempt");

  x.label("vm_do_preempt_check");
  x.movMemImm32(R.EBP, 0x0FFF0C, 0);   // clear preempt_flag
  x.movMemImm32(R.EBP, 0x0FFF14, 256); // reset quantum_countdown
  x.movRegMem32(R.EAX, R.EBP, 0x0FFF04); // num_active_tids
  x.cmpRegImm32(R.EAX, 1);
  x.jleLabel("vm_no_preempt");

  // Save current task (cur_tid) registers into TCB[cur_tid] at EBP + 0x0FFE00 + cur_tid * 32
  x.movRegMem32(R.ECX, R.EBP, 0x0FFF00); // ECX = cur_tid
  x.movRegReg32(R.EBX, R.ECX);
  x.shlRegImm(R.EBX, 5);
  x.addRegReg32(R.EBX, R.EBP);
  x.addRegImm32(R.EBX, 0x0FFE00);        // EBX = &TCB[cur_tid]
  x.movMemReg32(R.EBX, 4, R.ESI);        // vm_pc
  x.movMemReg32(R.EBX, 8, R.EDI);        // vm_sp
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_VM_FP);
  x.movMemReg32(R.EBX, 12, R.EAX);       // vm_fp
  x.movRegMem32(R.EAX, R.EDX, ADDR_VM_CSP);
  x.movMemReg32(R.EBX, 16, R.EAX);       // vm_csp

  // Round-robin scan for next runnable task (ECX = cur_tid)
  x.label("sched_pick_next");
  x.movRegImm32(R.EDX, 8);
  x.label("sched_scan_loop");
  x.addRegImm32(R.ECX, 1);
  x.andRegImm32(R.ECX, 7);
  x.movRegReg32(R.EBX, R.ECX);
  x.shlRegImm(R.EBX, 5);
  x.addRegReg32(R.EBX, R.EBP);
  x.addRegImm32(R.EBX, 0x0FFE00);
  x.movRegMem32(R.EAX, R.EBX, 0);        // TCB.state
  x.cmpRegImm32(R.EAX, 1);
  x.jeLabel("sched_found");
  x.subRegImm32(R.EDX, 1);
  x.jneLabel("sched_scan_loop");
  x.jmpLabel("vm_no_preempt");

  x.label("sched_found");
  x.movMemReg32(R.EBP, 0x0FFF00, R.ECX); // cur_tid = cand
  x.movRegMem32(R.EAX, R.EBP, 0x0FFF10);
  x.addRegImm32(R.EAX, 1);
  x.movMemReg32(R.EBP, 0x0FFF10, R.EAX); // context_switches++
  x.movRegMem32(R.EAX, R.EBX, 20);
  x.addRegImm32(R.EAX, 1);
  x.movMemReg32(R.EBX, 20, R.EAX);       // TCB.ticks++
  x.movRegMem32(R.ESI, R.EBX, 4);        // load VM_PC
  x.movRegMem32(R.EDI, R.EBX, 8);        // load VM_SP
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EBX, 12);
  x.movMemReg32(R.EDX, ADDR_VM_FP, R.EAX);
  x.movRegMem32(R.EAX, R.EBX, 16);
  x.movMemReg32(R.EDX, ADDR_VM_CSP, R.EAX);

  x.label("vm_no_preempt");
  // EBX = inst = i32[EBP + ESI]; ESI += 4; [ADDR_VM_ICNT]++
  x.movRegSib32(R.EBX, R.EBP, R.ESI, 0, 0);
  x.addRegImm32(R.ESI, 4);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_VM_ICNT);
  x.addRegImm32(R.EAX, 1);
  x.movMemReg32(R.EDX, ADDR_VM_ICNT, R.EAX);

  // EAX = op = EBX >>> 24
  x.movRegReg32(R.EAX, R.EBX);
  x.shrRegImm(R.EAX, 24);
  x.cmpRegImm32(R.EAX, 0x28);
  x.jgLabel("vm_halt_bad_op");

  x.movRegLabel32(R.EDX, "op_table");
  x.movRegSib32(R.EAX, R.EDX, R.EAX, 2, 0);
  x.jmpReg32(R.EAX);

  // --------------------------------------------------------------------------
  // Hardware Interrupt Service Routines (Protected Mode IDT)
  // --------------------------------------------------------------------------
  x.label("isr_default");
  x.u8(0xCF); // iretd

  x.label("isr_irq0_timer");
  x.pushReg32(R.EAX);
  x.pushReg32(R.EDX);
  x.movRegImm32(R.EDX, 0x002FFF00);
  x.movRegMem32(R.EAX, R.EDX, 8);  // irq0_ticks
  x.addRegImm32(R.EAX, 1);
  x.movMemReg32(R.EDX, 8, R.EAX);
  x.movMemImm32(R.EDX, 12, 1);     // preempt_flag = 1
  x.movRegImm32(R.EAX, 0x20);
  x.outImm8Al(0x20);               // Master PIC EOI
  x.popReg32(R.EDX);
  x.popReg32(R.EAX);
  x.u8(0xCF);                      // iretd

  // --------------------------------------------------------------------------
  // Opcode Handlers (0x00 .. 0x27)
  // --------------------------------------------------------------------------

  x.label("op_00_nop");
  x.jmpLabel("vm_loop");

  x.label("op_01_halt");
  x.subRegImm32(R.EDI, 4);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.jmpLabel("vm_halt_with_eax");

  x.label("op_02_push_i16");
  x.movRegReg32(R.EAX, R.EBX);
  x.shlRegImm(R.EAX, 16);
  x.sarRegImm(R.EAX, 16);
  x.movSibReg32(R.EBP, R.EDI, 0, 0, R.EAX);
  x.addRegImm32(R.EDI, 4);
  x.jmpLabel("vm_loop");

  x.label("op_03_push_u16");
  x.movRegReg32(R.EAX, R.EBX);
  x.andRegImm32(R.EAX, 0xFFFF);
  x.movSibReg32(R.EBP, R.EDI, 0, 0, R.EAX);
  x.addRegImm32(R.EDI, 4);
  x.jmpLabel("vm_loop");

  x.label("op_04_push_hi");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, -4);
  x.andRegImm32(R.EAX, 0xFFFF);
  x.movRegReg32(R.ECX, R.EBX);
  x.shlRegImm(R.ECX, 16);
  x.orRegReg32(R.EAX, R.ECX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX);
  x.jmpLabel("vm_loop");

  x.label("op_05_dup");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, -4);
  x.movSibReg32(R.EBP, R.EDI, 0, 0, R.EAX);
  x.addRegImm32(R.EDI, 4);
  x.jmpLabel("vm_loop");

  x.label("op_06_drop");
  x.subRegImm32(R.EDI, 4);
  x.jmpLabel("vm_loop");

  x.label("op_07_swap");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, -4);
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, -8);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.ECX);
  x.movSibReg32(R.EBP, R.EDI, 0, -8, R.EAX);
  x.jmpLabel("vm_loop");

  x.label("op_08_get_local");
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0xFFFF);
  x.shlRegImm(R.ECX, 2);
  x.xorRegReg32(R.EDX, R.EDX);
  x.addRegReg32(R.ECX, R.EBP);
  x.movRegMem32(R.EAX, R.EDX, ADDR_VM_FP);
  x.movRegSib32(R.EAX, R.ECX, R.EAX, 0, 0);
  x.movSibReg32(R.EBP, R.EDI, 0, 0, R.EAX);
  x.addRegImm32(R.EDI, 4);
  x.jmpLabel("vm_loop");

  x.label("op_09_set_local");
  x.subRegImm32(R.EDI, 4);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0xFFFF);
  x.shlRegImm(R.ECX, 2);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EDX, R.EDX, ADDR_VM_FP);
  x.addRegReg32(R.ECX, R.EDX);
  x.movSibReg32(R.EBP, R.ECX, 0, 0, R.EAX);
  x.jmpLabel("vm_loop");

  // 0x0A: GET_GLOBAL (at 0x020000)
  x.label("op_0a_get_global");
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0xFFFF);
  x.movRegSib32(R.EAX, R.EBP, R.ECX, 2, 0x020000);
  x.movSibReg32(R.EBP, R.EDI, 0, 0, R.EAX);
  x.addRegImm32(R.EDI, 4);
  x.jmpLabel("vm_loop");

  // 0x0B: SET_GLOBAL (at 0x020000)
  x.label("op_0b_set_global");
  x.subRegImm32(R.EDI, 4);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0xFFFF);
  x.movSibReg32(R.EBP, R.ECX, 2, 0x020000, R.EAX);
  x.jmpLabel("vm_loop");

  // 0x0C: ADDR_LOCAL
  x.label("op_0c_addr_local");
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0xFFFF);
  x.shlRegImm(R.ECX, 2);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_VM_FP);
  x.addRegReg32(R.EAX, R.ECX);
  x.movSibReg32(R.EBP, R.EDI, 0, 0, R.EAX);
  x.addRegImm32(R.EDI, 4);
  x.jmpLabel("vm_loop");

  // 0x0D: ADDR_GLOBAL (at 0x020000)
  x.label("op_0d_addr_global");
  x.movRegReg32(R.EAX, R.EBX);
  x.andRegImm32(R.EAX, 0xFFFF);
  x.shlRegImm(R.EAX, 2);
  x.addRegImm32(R.EAX, 0x020000);
  x.movSibReg32(R.EBP, R.EDI, 0, 0, R.EAX);
  x.addRegImm32(R.EDI, 4);
  x.jmpLabel("vm_loop");

  let eaLblSeq = 0;
  function calcLoadAddr() {
    const id = eaLblSeq++;
    x.movRegReg32(R.ECX, R.EBX);
    x.shlRegImm(R.ECX, 16);
    x.sarRegImm(R.ECX, 16);
    x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, -4);
    x.addRegReg32(R.ECX, R.EAX);
    x.xorRegReg32(R.EDX, R.EDX);
    x.movRegMem32(R.EAX, R.EDX, ADDR_VM_RAM_SIZE);
    x.cmpRegReg32(R.ECX, R.EAX);
    x.jbLabel("ld_ea_ok_" + id);
    x.andRegImm32(R.ECX, 0x003FFFFF);
    x.label("ld_ea_ok_" + id);
  }

  x.label("op_0e_load8u");
  calcLoadAddr();
  x.movzxRegSib8(R.EAX, R.EBP, R.ECX, 0, 0);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX);
  x.jmpLabel("vm_loop");

  x.label("op_0f_load8s");
  calcLoadAddr();
  x.movsxRegSib8(R.EAX, R.EBP, R.ECX, 0, 0);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX);
  x.jmpLabel("vm_loop");

  x.label("op_10_load16u");
  calcLoadAddr();
  x.movzxRegSib16(R.EAX, R.EBP, R.ECX, 0, 0);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX);
  x.jmpLabel("vm_loop");

  x.label("op_11_load32");
  calcLoadAddr();
  x.movRegSib32(R.EAX, R.EBP, R.ECX, 0, 0);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX);
  x.jmpLabel("vm_loop");

  function calcStoreAddrVal() {
    const id = eaLblSeq++;
    x.subRegImm32(R.EDI, 8);
    x.movRegReg32(R.EDX, R.EBX);
    x.shlRegImm(R.EDX, 16);
    x.sarRegImm(R.EDX, 16);
    x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 0);
    x.addRegReg32(R.EDX, R.ECX);
    x.xorRegReg32(R.ECX, R.ECX);
    x.movRegMem32(R.EAX, R.ECX, ADDR_VM_RAM_SIZE);
    x.cmpRegReg32(R.EDX, R.EAX);
    x.jbLabel("st_ea_ok_" + id);
    x.andRegImm32(R.EDX, 0x003FFFFF);
    x.label("st_ea_ok_" + id);
    x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 4);
  }

  x.label("op_12_store8");
  calcStoreAddrVal();
  x.movSibReg8(R.EBP, R.EDX, 0, 0, R.AL);
  x.jmpLabel("vm_loop");

  x.label("op_13_store16");
  calcStoreAddrVal();
  x.movSibReg16(R.EBP, R.EDX, 0, 0, R.AX);
  x.jmpLabel("vm_loop");

  x.label("op_14_store32");
  calcStoreAddrVal();
  x.movSibReg32(R.EBP, R.EDX, 0, 0, R.EAX);
  x.jmpLabel("vm_loop");

  function popBinArgs() {
    x.subRegImm32(R.EDI, 4);
    x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, -4);
    x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 0);
  }

  x.label("op_15_add");
  popBinArgs(); x.addRegReg32(R.EAX, R.ECX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");

  x.label("op_16_sub");
  popBinArgs(); x.subRegReg32(R.EAX, R.ECX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");

  x.label("op_17_mul");
  popBinArgs(); x.imulRegReg32(R.EAX, R.ECX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");

  x.label("op_18_div");
  popBinArgs();
  x.cmpRegImm32(R.ECX, 0);
  x.jneLabel("div_nonzero");
  x.xorRegReg32(R.EAX, R.EAX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX);
  x.jmpLabel("vm_loop");
  x.label("div_nonzero");
  x.cmpRegImm32(R.ECX, -1);
  x.jneLabel("div_safe");
  x.cmpRegImm32(R.EAX, -2147483648);
  x.jeLabel("div_store");
  x.label("div_safe");
  x.cdq();
  x.idivReg32(R.ECX);
  x.label("div_store");
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX);
  x.jmpLabel("vm_loop");

  x.label("op_19_mod");
  popBinArgs();
  x.cmpRegImm32(R.ECX, 0);
  x.jeLabel("mod_zero");
  x.cmpRegImm32(R.ECX, -1);
  x.jeLabel("mod_zero");
  x.cdq();
  x.idivReg32(R.ECX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EDX);
  x.jmpLabel("vm_loop");
  x.label("mod_zero");
  x.xorRegReg32(R.EAX, R.EAX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX);
  x.jmpLabel("vm_loop");

  x.label("op_1a_and");
  popBinArgs(); x.andRegReg32(R.EAX, R.ECX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");

  x.label("op_1b_or");
  popBinArgs(); x.orRegReg32(R.EAX, R.ECX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");

  x.label("op_1c_xor");
  popBinArgs(); x.xorRegReg32(R.EAX, R.ECX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");

  x.label("op_1d_shl");
  popBinArgs(); x.andRegImm32(R.ECX, 31); x.shlRegCl(R.EAX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");

  x.label("op_1e_shr");
  popBinArgs(); x.andRegImm32(R.ECX, 31); x.shrRegCl(R.EAX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");

  x.label("op_1f_sar");
  popBinArgs(); x.andRegImm32(R.ECX, 31); x.sarRegCl(R.EAX);
  x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");

  x.label("op_20_cmp");
  x.movRegReg32(R.EDX, R.EBX);
  x.shrRegImm(R.EDX, 16);
  x.andRegImm32(R.EDX, 0xFF);
  x.jneLabel("cmp_imm16");
  popBinArgs();
  x.movRegReg32(R.EDX, R.EBX);
  x.jmpLabel("cmp_do");
  x.label("cmp_imm16");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, -4);
  x.movRegReg32(R.ECX, R.EBX);
  x.shlRegImm(R.ECX, 16);
  x.sarRegImm(R.ECX, 16);
  x.label("cmp_do");
  x.andRegImm32(R.EDX, 7);
  x.movRegLabel32(R.EBX, "cmp_table");
  x.movRegSib32(R.EDX, R.EBX, R.EDX, 2, 0);
  x.cmpRegReg32(R.EAX, R.ECX);
  x.movRegImm32(R.EAX, 0);
  x.jmpReg32(R.EDX);

  x.label("cmp_0_eq");  x.setccAl(0x94); x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");
  x.label("cmp_1_ne");  x.setccAl(0x95); x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");
  x.label("cmp_2_lt");  x.setccAl(0x9C); x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");
  x.label("cmp_3_le");  x.setccAl(0x9E); x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");
  x.label("cmp_4_gt");  x.setccAl(0x9F); x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");
  x.label("cmp_5_ge");  x.setccAl(0x9D); x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");
  x.label("cmp_6_ult"); x.setccAl(0x92); x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");
  x.label("cmp_7_ugt"); x.setccAl(0x97); x.movSibReg32(R.EBP, R.EDI, 0, -4, R.EAX); x.jmpLabel("vm_loop");

  x.label("op_21_jmp");
  x.movRegReg32(R.ESI, R.EBX);
  x.andRegImm32(R.ESI, 0x00FFFFFF);
  x.jmpLabel("vm_loop");

  x.label("op_22_jz");
  x.subRegImm32(R.EDI, 4);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.cmpRegImm32(R.EAX, 0);
  x.jneLabel("vm_loop");
  x.movRegReg32(R.ESI, R.EBX);
  x.andRegImm32(R.ESI, 0x00FFFFFF);
  x.jmpLabel("vm_loop");

  x.label("op_23_jnz");
  x.subRegImm32(R.EDI, 4);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("vm_loop");
  x.movRegReg32(R.ESI, R.EBX);
  x.andRegImm32(R.ESI, 0x00FFFFFF);
  x.jmpLabel("vm_loop");

  x.label("op_24_call");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.ECX, R.EDX, ADDR_VM_CSP);
  x.movRegMem32(R.EAX, R.EDX, ADDR_VM_FP);
  x.movRegReg32(R.EDX, R.EBX);
  x.andRegImm32(R.EDX, 0x00800000);
  x.orRegReg32(R.EAX, R.EDX);
  x.movSibReg32(R.EBP, R.ECX, 0, 0, R.ESI);
  x.movSibReg32(R.EBP, R.ECX, 0, 4, R.EAX);
  x.addRegImm32(R.ECX, 8);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movMemReg32(R.EDX, ADDR_VM_CSP, R.ECX);
  x.movRegReg32(R.ESI, R.EBX);
  x.andRegImm32(R.ESI, 0x007FFFFF);
  x.jmpLabel("vm_loop");

  x.label("op_28_call_ind");
  x.subRegImm32(R.EDI, 4);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.pushReg32(R.EAX);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.ECX, R.EDX, ADDR_VM_CSP);
  x.movRegMem32(R.EAX, R.EDX, ADDR_VM_FP);
  x.movRegReg32(R.EDX, R.EBX);
  x.andRegImm32(R.EDX, 0x00800000);
  x.orRegReg32(R.EAX, R.EDX);
  x.movSibReg32(R.EBP, R.ECX, 0, 0, R.ESI);
  x.movSibReg32(R.EBP, R.ECX, 0, 4, R.EAX);
  x.addRegImm32(R.ECX, 8);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movMemReg32(R.EDX, ADDR_VM_CSP, R.ECX);
  x.popReg32(R.ESI);
  x.andRegImm32(R.ESI, 0x007FFFFF);
  x.jmpLabel("vm_loop");

  x.label("op_25_enter");
  x.movRegReg32(R.EAX, R.EBX);
  x.shrRegImm(R.EAX, 16);
  x.andRegImm32(R.EAX, 0xFF);
  x.shlRegImm(R.EAX, 2);
  x.movRegReg32(R.ECX, R.EDI);
  x.subRegReg32(R.ECX, R.EAX);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movMemReg32(R.EDX, ADDR_VM_FP, R.ECX);
  x.movRegReg32(R.EAX, R.EBX);
  x.andRegImm32(R.EAX, 0xFFFF);
  x.shlRegImm(R.EAX, 2);
  x.movRegReg32(R.EDI, R.ECX);
  x.addRegReg32(R.EDI, R.EAX);
  x.jmpLabel("vm_loop");

  x.label("op_26_ret");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, -4);
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0x00FF0000);
  x.jeLabel("ret_from_stk");
  x.movRegReg32(R.EAX, R.EBX);
  x.shlRegImm(R.EAX, 16);
  x.sarRegImm(R.EAX, 16);
  x.label("ret_from_stk");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EDI, R.EDX, ADDR_VM_FP);
  x.movSibReg32(R.EBP, R.EDI, 0, 0, R.EAX);
  x.addRegImm32(R.EDI, 4);
  x.movRegMem32(R.ECX, R.EDX, ADDR_VM_CSP);
  x.subRegImm32(R.ECX, 8);
  x.movMemReg32(R.EDX, ADDR_VM_CSP, R.ECX);
  x.movRegSib32(R.ESI, R.EBP, R.ECX, 0, 0);
  x.movRegSib32(R.EAX, R.EBP, R.ECX, 0, 4);
  x.movRegReg32(R.ECX, R.EAX);
  x.shrRegImm(R.ECX, 21);
  x.andRegImm32(R.ECX, 4);
  x.subRegReg32(R.EDI, R.ECX);
  x.andRegImm32(R.EAX, 0x007FFFFF);
  x.movMemReg32(R.EDX, ADDR_VM_FP, R.EAX);
  x.jmpLabel("vm_loop");

  // ==========================================================================
  // 3. System Call Dispatcher (0x27: SYSCALL [nargs:8][sysnum:16])
  // ==========================================================================
  x.label("op_27_syscall");
  x.movRegReg32(R.EAX, R.EBX);
  x.shrRegImm(R.EAX, 16);
  x.andRegImm32(R.EAX, 0xFF);
  x.movRegReg32(R.ECX, R.EAX);
  x.shlRegImm(R.EAX, 2);
  x.subRegReg32(R.EDI, R.EAX);

  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_VM_ICNT);
  x.movMemReg32(R.EBP, 0x0FFD20, R.EAX);

  x.andRegImm32(R.EBX, 0xFFFF);

  for (let s = 0; s <= 27; s++) {
    x.cmpRegImm32(R.EBX, s);
    x.jeLabel("sys_" + String(s).padStart(2, "0"));
  }
  x.movRegImm32(R.EAX, -1);

  x.label("sys_push_eax");
  x.movSibReg32(R.EBP, R.EDI, 0, 0, R.EAX);
  x.addRegImm32(R.EDI, 4);
  x.jmpLabel("vm_loop");

  // --------------------------------------------------------------------------
  // Subroutine: Poll 8042 PS/2 Controller (Keyboard Set 1 + 3-Byte Mouse)
  // --------------------------------------------------------------------------
  x.label("sub_poll_ps2");
  x.pushReg32(R.EBX);
  x.pushReg32(R.ECX);
  x.pushReg32(R.EDX);

  x.label("ps2_poll_next");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_KEY_EVENT);
  x.cmpRegImm32(R.EAX, 0);
  x.jneLabel("ps2_poll_done");
  x.inAlImm8(0x64);
  x.andRegImm32(R.EAX, 0xFF);
  x.cmpRegImm32(R.EAX, 0xFF);
  x.jeLabel("ps2_poll_done");
  x.movRegReg32(R.ECX, R.EAX);
  x.andRegImm32(R.EAX, 0x01);
  x.jeLabel("ps2_poll_done");

  x.inAlImm8(0x60);
  x.andRegImm32(R.EAX, 0xFF);
  x.andRegImm32(R.ECX, 0x20);
  x.jneLabel("ps2_is_mouse");

  x.cmpRegImm32(R.EAX, 0xE0);
  x.jeLabel("ps2_poll_next");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegReg32(R.EBX, R.EAX);
  x.andRegImm32(R.EBX, 0x7F);
  x.movRegReg32(R.ECX, R.EAX);
  x.andRegImm32(R.ECX, 0x80);
  x.movRegMem32(R.EDX, R.EDX, ADDR_KEY_MODS);
  x.andRegImm32(R.EDX, 1);
  x.jneLabel("ps2_use_shift_tbl");
  x.movRegLabel32(R.EDX, "scancode_plain_tbl");
  x.jmpLabel("ps2_lookup_done");
  x.label("ps2_use_shift_tbl");
  x.movRegLabel32(R.EDX, "scancode_shift_tbl");
  x.label("ps2_lookup_done");
  x.movzxRegSib16(R.EBX, R.EDX, R.EBX, 1, 0);
  x.cmpRegImm32(R.EBX, 4);
  x.jleLabel("ps2_shift_key");
  x.cmpRegImm32(R.ECX, 0);
  x.jneLabel("ps2_poll_next");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EDX, R.EDX, ADDR_KEY_MODS);
  x.shlRegImm(R.EDX, 24);
  x.orRegReg32(R.EBX, R.EDX);
  x.orRegImm32(R.EBX, 0x00010000);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movMemReg32(R.EDX, ADDR_KEY_EVENT, R.EBX);
  x.jmpLabel("ps2_poll_done");

  x.label("ps2_shift_key");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_KEY_MODS);
  x.cmpRegImm32(R.ECX, 0);
  x.jneLabel("ps2_shift_up");
  x.orRegReg32(R.EAX, R.EBX);
  x.movMemReg32(R.EDX, ADDR_KEY_MODS, R.EAX);
  x.jmpLabel("ps2_poll_next");
  x.label("ps2_shift_up");
  x.movRegImm32(R.ECX, 7);
  x.subRegReg32(R.ECX, R.EBX);
  x.andRegReg32(R.EAX, R.ECX);
  x.movMemReg32(R.EDX, ADDR_KEY_MODS, R.EAX);
  x.jmpLabel("ps2_poll_next");

  x.label("ps2_is_mouse");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EBX, R.EDX, ADDR_MOUSE_STAGE);
  x.cmpRegImm32(R.EBX, 0);
  x.jeLabel("ms_stage0");
  x.cmpRegImm32(R.EBX, 1);
  x.jeLabel("ms_stage1");

  // 1.2.1 H2: decode the 3-byte packet with the 9-bit deltas the PS/2 protocol
  // actually sends (sign bits in byte 0: bit 4 = X sign, bit 5 = Y sign), and drop
  // the movement of any packet whose overflow bits (6, 7) are set. Buttons still update.
  // (replacing spiralos/core/core_x86.js 1.2 lines: 8-bit sign-extension of bytes 1 and 2)
  x.movMemImm32(R.EDX, ADDR_MOUSE_STAGE, 0);
  x.movRegMem32(R.EBX, R.EDX, ADDR_MOUSE_B0);
  // 1.6.1: Record raw 3-byte packet (b0 | b1<<8 | b2<<16) for /home/mouse.log diagnostic
  x.pushReg32(R.EAX);
  x.shlRegImm(R.EAX, 16);
  x.movRegMem32(R.ECX, R.EDX, ADDR_MOUSE_B1);
  x.andRegImm32(R.ECX, 0xFF);
  x.shlRegImm(R.ECX, 8);
  x.orRegReg32(R.EAX, R.ECX);
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0xFF);
  x.orRegReg32(R.EAX, R.ECX);
  x.movMemReg32(R.EBP, 0x0FFDA4, R.EAX);
  x.movRegMem32(R.EAX, R.EBP, 0x0FFDA0);
  x.addRegImm32(R.EAX, 1);
  x.movMemReg32(R.EBP, 0x0FFDA0, R.EAX);
  x.popReg32(R.EAX);
  // Defensive sync check on byte 0 bit 3 before decoding movement
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0x08);
  x.jeLabel("ms_skip_move");
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0xC0);
  x.jneLabel("ms_skip_move");

  // dY: EAX = byte 2 (0..255), minus 256 if the Y sign bit is set
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0x20);
  x.jeLabel("ms_dy_pos");
  x.subRegImm32(R.EAX, 256);
  x.label("ms_dy_pos");
  x.movRegMem32(R.ECX, R.EDX, ADDR_MOUSE_Y);
  x.subRegReg32(R.ECX, R.EAX);
  x.cmpRegImm32(R.ECX, 0); x.jgeLabel("ms_y_min_ok"); x.xorRegReg32(R.ECX, R.ECX);
  x.label("ms_y_min_ok");
  x.cmpRegImm32(R.ECX, 199); x.jleLabel("ms_y_max_ok"); x.movRegImm32(R.ECX, 199);
  x.label("ms_y_max_ok");
  x.movMemReg32(R.EDX, ADDR_MOUSE_Y, R.ECX);
  x.movMemReg32(R.EBP, 0x0FFD0C, R.ECX);

  // dX: EAX = byte 1 (0..255), minus 256 if the X sign bit is set
  x.movRegMem32(R.EAX, R.EDX, ADDR_MOUSE_B1);
  x.andRegImm32(R.EAX, 0xFF);
  x.movRegReg32(R.ECX, R.EBX);
  x.andRegImm32(R.ECX, 0x10);
  x.jeLabel("ms_dx_pos");
  x.subRegImm32(R.EAX, 256);
  x.label("ms_dx_pos");
  x.movRegMem32(R.ECX, R.EDX, ADDR_MOUSE_X);
  x.addRegReg32(R.ECX, R.EAX);
  x.cmpRegImm32(R.ECX, 0); x.jgeLabel("ms_x_min_ok"); x.xorRegReg32(R.ECX, R.ECX);
  x.label("ms_x_min_ok");
  x.cmpRegImm32(R.ECX, 319); x.jleLabel("ms_x_max_ok"); x.movRegImm32(R.ECX, 319);
  x.label("ms_x_max_ok");
  x.movMemReg32(R.EDX, ADDR_MOUSE_X, R.ECX);
  x.movMemReg32(R.EBP, 0x0FFD08, R.ECX);

  x.label("ms_skip_move");
  x.movRegReg32(R.EAX, R.EBX);
  x.andRegImm32(R.EAX, 0x07);
  x.movMemReg32(R.EDX, ADDR_MOUSE_BTN, R.EAX);
  x.movMemReg32(R.EBP, 0x0FFD10, R.EAX);
  x.jmpLabel("ps2_poll_next");

  x.label("ms_stage0");
  // 1.2.1 H2: packet sync. Byte 0 of every PS/2 mouse packet has bit 3 set; a byte
  // without it can't be a packet start (a late ID byte, a stray ACK tail, a dropped
  // byte), so discard it and stay in stage 0. Without this, one stray byte shifts
  // every later packet by one byte forever (cursor pinned to an edge).
  x.movRegReg32(R.ECX, R.EAX);
  x.andRegImm32(R.ECX, 0x08);
  x.jneLabel("ms_sync_ok");
  // Sync drop: bit 3 of byte 0 is 0 -> record bad byte (bit 31 set) & increment drop counter
  x.movRegReg32(R.ECX, R.EAX);
  x.orRegImm32(R.ECX, 0x80000000);
  x.movMemReg32(R.EBP, 0x0FFDA4, R.ECX);
  x.movRegMem32(R.ECX, R.EBP, 0x0FFDA0);
  x.addRegImm32(R.ECX, 1);
  x.movMemReg32(R.EBP, 0x0FFDA0, R.ECX);
  x.movRegMem32(R.ECX, R.EBP, 0x0FFDA8);
  x.addRegImm32(R.ECX, 1);
  x.movMemReg32(R.EBP, 0x0FFDA8, R.ECX);
  x.jmpLabel("ps2_poll_next");
  x.label("ms_sync_ok");
  x.movMemReg32(R.EDX, ADDR_MOUSE_B0, R.EAX);
  x.movMemImm32(R.EDX, ADDR_MOUSE_STAGE, 1);
  x.jmpLabel("ps2_poll_next");

  x.label("ms_stage1");
  x.movMemReg32(R.EDX, ADDR_MOUSE_B1, R.EAX);
  x.movMemImm32(R.EDX, ADDR_MOUSE_STAGE, 2);
  x.jmpLabel("ps2_poll_next");

  x.label("ps2_poll_done");
  x.popReg32(R.EDX);
  x.popReg32(R.ECX);
  x.popReg32(R.EBX);
  x.ret();

  // --------------------------------------------------------------------------
  // Syscall Implementations (0 .. 21)
  // --------------------------------------------------------------------------

  // SYS 0: EXIT(code)
  x.label("sys_00");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.jmpLabel("vm_halt_with_eax");

  // SYS 1: YIELD() -> 2x scale 320x200x8 vmRam[0x0F0000] into 640x480x32 or 640x480x24 VBE LFB at 0xE0000000
  x.label("sys_01");
  x.callLabel("sub_poll_ps2");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);

  x.movRegMem32(R.EAX, R.EBP, 0x0FFD04);
  x.addRegImm32(R.EAX, 1);
  x.movMemReg32(R.EBP, 0x0FFD04, R.EAX);

  // Build 256-entry 32-bit 0x00RRGGBB lookup table at 0x00007400 from vmRam[0x0FFA00]
  x.movRegImm32(R.ESI, 0x002FFA00);
  x.movRegImm32(R.EDI, 0x00007400);
  x.movRegImm32(R.ECX, 256);
  x.label("pal_lut_loop");
  x.movzxRegMem8(R.EAX, R.ESI, 0); // R
  x.shlRegImm(R.EAX, 16);
  x.movzxRegMem8(R.EBX, R.ESI, 1); // G
  x.shlRegImm(R.EBX, 8);
  x.orRegReg32(R.EAX, R.EBX);
  x.movzxRegMem8(R.EBX, R.ESI, 2); // B
  x.orRegReg32(R.EAX, R.EBX);
  x.movMemReg32(R.EDI, 0, R.EAX);
  x.addRegImm32(R.ESI, 3);
  x.addRegImm32(R.EDI, 4);
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("pal_lut_loop");

  // 1.2 F3: Read BytesPerScanLine (u16 at 0x00005010 from VBE ModeInfoBlock)
  // (replacing spiralos/core/core_x86.js:1300-1361)
  x.pushReg32(R.EBP);
  x.xorRegReg32(R.EBX, R.EBX);
  x.u8(0x0F); x.u8(0xB7); x.memRegDisp(R.ECX, R.EBX, 0x5010); // movzx ecx, word [ebx + 0x5010]
  x.cmpRegImm32(R.ECX, 0);
  x.jneLabel("vbe_pitch_ok");
  x.movRegImm32(R.ECX, 2560);
  x.label("vbe_pitch_ok");
  x.movMemReg32(R.EBX, 0x7800, R.ECX); // store pitch at [0x7800]

  // Compute y=40 vertical centering offset: EDI = 0xE0000000 + 40 * pitch
  x.movRegReg32(R.EDI, R.ECX);
  x.shlRegImm(R.EDI, 5);
  x.movRegReg32(R.EAX, R.ECX);
  x.shlRegImm(R.EAX, 3);
  x.addRegReg32(R.EDI, R.EAX);
  x.addRegImm32(R.EDI, 0xE0000000);

  // Check VBE BitsPerPixel at 0x00005019 (24 vs 32)
  x.movzxRegMem8(R.EAX, R.EBX, 0x5019);
  x.cmpRegImm32(R.EAX, 24);
  x.jeLabel("blit_24bpp");

  // 32-bpp Blitter using dynamic VBE pitch from [0x7800] (2x unrolled)
  x.movRegImm32(R.ESI, 0x002F0000);
  x.movRegImm32(R.EDX, 200);
  x.xorRegReg32(R.EBX, R.EBX);
  x.label("blit_y_loop");
  x.movRegMem32(R.EBP, R.EBX, 0x7800);
  x.addRegReg32(R.EBP, R.EDI); // EBP = EDI + pitch (odd scanline)
  x.movRegImm32(R.ECX, 160);
  x.label("blit_x_loop");
  x.movzxRegMem8(R.EAX, R.ESI, 0);
  x.movRegSib32(R.EAX, R.EBX, R.EAX, 2, 0x7400);
  x.movMemReg32(R.EDI, 0, R.EAX);
  x.movMemReg32(R.EDI, 4, R.EAX);
  x.movMemReg32(R.EBP, 0, R.EAX);
  x.movMemReg32(R.EBP, 4, R.EAX);
  x.movzxRegMem8(R.EAX, R.ESI, 1);
  x.movRegSib32(R.EAX, R.EBX, R.EAX, 2, 0x7400);
  x.movMemReg32(R.EDI, 8, R.EAX);
  x.movMemReg32(R.EDI, 12, R.EAX);
  x.movMemReg32(R.EBP, 8, R.EAX);
  x.movMemReg32(R.EBP, 12, R.EAX);
  x.addRegImm32(R.ESI, 2);
  x.addRegImm32(R.EDI, 16);
  x.addRegImm32(R.EBP, 16);
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("blit_x_loop");
  x.subRegImm32(R.EDI, 2560);
  x.xorRegReg32(R.EBX, R.EBX);
  x.movRegMem32(R.EAX, R.EBX, 0x7800);
  x.addRegReg32(R.EDI, R.EAX);
  x.addRegReg32(R.EDI, R.EAX); // advance EDI by 2 * pitch
  x.subRegImm32(R.EDX, 1);
  x.jneLabel("blit_y_loop");
  x.jmpLabel("blit_done");

  // 24-bpp Blitter using dynamic VBE pitch from [0x7800]
  x.label("blit_24bpp");
  x.movRegImm32(R.ESI, 0x002F0000);
  x.movRegImm32(R.EDX, 200);
  x.label("blit24_y_loop");
  x.xorRegReg32(R.EBX, R.EBX);
  x.movRegMem32(R.EBP, R.EBX, 0x7800);
  x.addRegReg32(R.EBP, R.EDI); // EBP = EDI + pitch (odd scanline)
  x.movRegImm32(R.ECX, 320);
  x.label("blit24_x_loop");
  x.movzxRegMem8(R.EAX, R.ESI, 0);
  x.xorRegReg32(R.EBX, R.EBX);
  x.movRegSib32(R.EAX, R.EBX, R.EAX, 2, 0x7400); // AL=B, AH=G, EAX>>16=R
  x.movMemReg8(R.EDI, 0, R.AL);
  x.movMemReg8(R.EDI, 3, R.AL);
  x.movMemReg8(R.EBP, 0, R.AL);
  x.movMemReg8(R.EBP, 3, R.AL);
  x.movMemReg8(R.EDI, 1, R.AH);
  x.movMemReg8(R.EDI, 4, R.AH);
  x.movMemReg8(R.EBP, 1, R.AH);
  x.movMemReg8(R.EBP, 4, R.AH);
  x.shrRegImm(R.EAX, 16);
  x.movMemReg8(R.EDI, 2, R.AL);
  x.movMemReg8(R.EDI, 5, R.AL);
  x.movMemReg8(R.EBP, 2, R.AL);
  x.movMemReg8(R.EBP, 5, R.AL);
  x.addRegImm32(R.ESI, 1);
  x.addRegImm32(R.EDI, 6);
  x.addRegImm32(R.EBP, 6);
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("blit24_x_loop");
  x.subRegImm32(R.EDI, 1920);
  x.xorRegReg32(R.EBX, R.EBX);
  x.movRegMem32(R.EAX, R.EBX, 0x7800);
  x.addRegReg32(R.EDI, R.EAX);
  x.addRegReg32(R.EDI, R.EAX); // advance EDI by 2 * pitch
  x.subRegImm32(R.EDX, 1);
  x.jneLabel("blit24_y_loop");

  x.label("blit_done");
  x.popReg32(R.EBP);
  // Trigger preemptive check after frame yield
  x.movMemImm32(R.EBP, 0x0FFF0C, 1);
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  // SYS 2: TIME_MS() -> derive from irq0_ticks * 10 + frame counter * 16 + VM_ICNT / 512
  x.label("sys_02");
  if (opts && opts.brokenTimeMs) {
    // Positive control (b): old sum (frames*16 + ticks*8 + VM_ICNT/512)
    x.movRegMem32(R.EAX, R.EBP, 0x0FFD04);
    x.shlRegImm(R.EAX, 4);
    x.movRegMem32(R.ECX, R.EBP, 0x0FFF08);
    x.shlRegImm(R.ECX, 3);
    x.addRegReg32(R.EAX, R.ECX);
    x.xorRegReg32(R.EDX, R.EDX);
    x.movRegMem32(R.ECX, R.EDX, ADDR_VM_ICNT);
    x.shrRegImm(R.ECX, 9);
    x.addRegReg32(R.EAX, R.ECX);
    x.movMemReg32(R.EBP, 0x0FFD24, R.EAX);
    x.jmpLabel("sys_push_eax");
  } else {
    // KEHAI REAL-HW FIX (2026-11-15): time comes from the 100 Hz PIT only (ticks * 10 ms).
    // The old sum (frames*16 + ticks*8 + VM_ICNT/512) raced on fast real CPUs.
    x.movRegMem32(R.ECX, R.EBP, 0x0FFF08); // irq0_ticks
    x.movRegReg32(R.EAX, R.ECX);
    x.shlRegImm(R.EAX, 3);
    x.shlRegImm(R.ECX, 1);
    x.addRegReg32(R.EAX, R.ECX);
    x.movMemReg32(R.EBP, 0x0FFD24, R.EAX);
    x.jmpLabel("sys_push_eax");
  }

  // SYS 3: KEY_POLL()
  x.label("sys_03");
  x.callLabel("sub_poll_ps2");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_KEY_EVENT);
  x.movMemImm32(R.EDX, ADDR_KEY_EVENT, 0);
  x.jmpLabel("sys_push_eax");

  // SYS 4: MOUSE_POLL(out_ptr)
  x.label("sys_04");
  x.callLabel("sub_poll_ps2");
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 0);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_MOUSE_X);
  x.movRegMem32(R.EBX, R.EDX, ADDR_MOUSE_Y);
  x.cmpRegImm32(R.ECX, 0);
  x.jeLabel("ms_poll_pack");
  x.andRegImm32(R.ECX, 0x003FFFFF);
  x.movSibReg32(R.EBP, R.ECX, 0, 0, R.EAX);
  x.movSibReg32(R.EBP, R.ECX, 0, 4, R.EBX);
  x.movRegMem32(R.EDX, R.EDX, ADDR_MOUSE_BTN);
  x.movSibReg32(R.EBP, R.ECX, 0, 8, R.EDX);
  x.label("ms_poll_pack");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.ECX, R.EDX, ADDR_MOUSE_BTN);
  x.shlRegImm(R.ECX, 20);
  x.shlRegImm(R.EBX, 10);
  x.orRegReg32(R.EAX, R.EBX);
  x.orRegReg32(R.EAX, R.ECX);
  x.jmpLabel("sys_push_eax");

  // SYS 5: FILL_RECT(x, y, w, h, color)
  x.label("sys_05");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.movRegSib32(R.EBX, R.EBP, R.EDI, 0, 4);
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 8);
  x.movRegSib32(R.EDX, R.EBP, R.EDI, 0, 12);
  x.movRegSib32(R.ESI, R.EBP, R.EDI, 0, 16);

  x.cmpRegImm32(R.EAX, 0); x.jgeLabel("fr5_x_ok");
  x.addRegReg32(R.ECX, R.EAX); x.xorRegReg32(R.EAX, R.EAX);
  x.label("fr5_x_ok");
  x.cmpRegImm32(R.EBX, 0); x.jgeLabel("fr5_y_ok");
  x.addRegReg32(R.EDX, R.EBX); x.xorRegReg32(R.EBX, R.EBX);
  x.label("fr5_y_ok");
  x.movRegReg32(R.EDI, R.EAX); x.addRegReg32(R.EDI, R.ECX);
  x.cmpRegImm32(R.EDI, 320); x.jleLabel("fr5_w_ok");
  x.movRegImm32(R.ECX, 320); x.subRegReg32(R.ECX, R.EAX);
  x.label("fr5_w_ok");
  x.movRegReg32(R.EDI, R.EBX); x.addRegReg32(R.EDI, R.EDX);
  x.cmpRegImm32(R.EDI, 200); x.jleLabel("fr5_h_ok");
  x.movRegImm32(R.EDX, 200); x.subRegReg32(R.EDX, R.EBX);
  x.label("fr5_h_ok");

  x.cmpRegImm32(R.ECX, 0); x.jleLabel("fr5_done");
  x.cmpRegImm32(R.EDX, 0); x.jleLabel("fr5_done");

  x.movRegImm32(R.EDI, 320);
  x.imulRegReg32(R.EBX, R.EDI);
  x.addRegReg32(R.EBX, R.EAX);
  x.addRegImm32(R.EBX, 0x002F0000);
  x.movRegReg32(R.EAX, R.ESI);
  x.movRegReg32(R.ESI, R.ECX);

  x.label("fr5_row");
  x.movRegReg32(R.EDI, R.EBX);
  x.movRegReg32(R.ECX, R.ESI);
  x.repStosb();
  x.addRegImm32(R.EBX, 320);
  x.subRegImm32(R.EDX, 1);
  x.jneLabel("fr5_row");

  x.label("fr5_done");
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  // Internal subroutine: draw single 8x8 (font=0) or 8x16 (font=1) glyph (font in [0x7804])
  x.label("sub_draw_char");
  x.andRegImm32(R.ECX, 0xFF);
  x.subRegImm32(R.ECX, 32);
  x.cmpRegImm32(R.ECX, 0); x.jlLabel("dc6_ret");
  x.cmpRegImm32(R.ECX, 95); x.jgLabel("dc6_ret");
  x.cmpRegImm32(R.EAX, 0); x.jlLabel("dc6_ret");
  x.cmpRegImm32(R.EAX, 312); x.jgLabel("dc6_ret");
  x.cmpRegImm32(R.EBX, 0); x.jlLabel("dc6_ret");

  x.pushReg32(R.EDI);
  x.pushReg32(R.EBP);
  x.xorRegReg32(R.EDI, R.EDI);
  x.movRegMem32(R.EBP, R.EDI, 0x7804);
  x.cmpRegImm32(R.EBP, 0);
  x.jneLabel("dc6_serif");
  x.cmpRegImm32(R.EBX, 192); x.jgLabel("dc6_pop_ret");
  x.shlRegImm(R.ECX, 3);
  x.addRegImm32(R.ECX, 0x002EF000);
  x.movRegImm32(R.EBP, 8);
  x.jmpLabel("dc6_vram");

  x.label("dc6_serif");
  x.cmpRegImm32(R.EBX, 184); x.jgLabel("dc6_pop_ret");
  x.shlRegImm(R.ECX, 4);
  x.addRegImm32(R.ECX, 0x00291000);
  x.movRegImm32(R.EBP, 16);

  x.label("dc6_vram");
  x.movRegImm32(R.EDI, 320);
  x.imulRegReg32(R.EBX, R.EDI);
  x.addRegReg32(R.EBX, R.EAX);
  x.addRegImm32(R.EBX, 0x002F0000);
  x.movRegReg32(R.EDI, R.EBX);

  x.label("dc6_row");
  x.movzxRegMem8(R.EBX, R.ECX, 0);
  x.addRegImm32(R.ECX, 1);
  x.movRegImm32(R.EAX, 128);
  x.label("dc6_bit");
  x.pushReg32(R.EAX);
  x.andRegReg32(R.EAX, R.EBX);
  x.jeLabel("dc6_off");
  x.movMemReg8(R.EDI, 0, R.DL);
  x.jmpLabel("dc6_next");
  x.label("dc6_off");
  x.cmpRegImm32(R.ESI, 0);
  x.jlLabel("dc6_next");
  x.movRegReg32(R.EAX, R.ESI);
  x.movMemReg8(R.EDI, 0, R.AL);
  x.label("dc6_next");
  x.popReg32(R.EAX);
  x.addRegImm32(R.EDI, 1);
  x.shrRegImm(R.EAX, 1);
  x.jneLabel("dc6_bit");
  x.addRegImm32(R.EDI, 312);
  x.subRegImm32(R.EBP, 1);
  x.jneLabel("dc6_row");

  x.label("dc6_pop_ret");
  x.popReg32(R.EBP);
  x.popReg32(R.EDI);
  x.label("dc6_ret");
  x.ret();

  // SYS 6: DRAW_CHAR(x, y, ch, fg, bg[, font])
  x.label("sys_06");
  x.pushReg32(R.ESI);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 8);
  x.shrRegImm(R.EAX, 8);
  x.andRegImm32(R.EAX, 1);
  x.cmpRegImm32(R.ECX, 6);
  x.jlLabel("sys06_store_font");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 20);
  x.label("sys06_store_font");
  x.xorRegReg32(R.EBX, R.EBX);
  x.movMemReg32(R.EBX, 0x7804, R.EAX);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.movRegSib32(R.EBX, R.EBP, R.EDI, 0, 4);
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 8);
  x.movRegSib32(R.EDX, R.EBP, R.EDI, 0, 12);
  x.movRegSib32(R.ESI, R.EBP, R.EDI, 0, 16);
  x.callLabel("sub_draw_char");
  x.popReg32(R.ESI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  // SYS 7: DRAW_STR(x, y, str_ptr, fg, bg[, font])
  x.label("sys_07");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.cmpRegImm32(R.ECX, 6);
  x.jlLabel("sys07_store_font");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 20);
  x.label("sys07_store_font");
  x.xorRegReg32(R.EBX, R.EBX);
  x.movMemReg32(R.EBX, 0x7804, R.EAX);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.movRegSib32(R.EBX, R.EBP, R.EDI, 0, 4);
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 8);
  x.addRegReg32(R.ECX, R.EBP);
  x.movRegSib32(R.EDX, R.EBP, R.EDI, 0, 12);
  x.movRegSib32(R.ESI, R.EBP, R.EDI, 0, 16);
  x.movRegReg32(R.EDI, R.ECX);

  x.label("ds7_loop");
  x.movzxRegMem8(R.ECX, R.EDI, 0);
  x.cmpRegImm32(R.ECX, 0);
  x.jeLabel("ds7_done");
  x.pushReg32(R.EAX);
  x.pushReg32(R.EBX);
  x.pushReg32(R.EDX);
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.callLabel("sub_draw_char");
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.popReg32(R.EDX);
  x.popReg32(R.EBX);
  x.popReg32(R.EAX);
  x.addRegImm32(R.EAX, 8);
  x.addRegImm32(R.EDI, 1);
  x.jmpLabel("ds7_loop");

  x.label("ds7_done");
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  // SYS 8: MEMCPY(dst, src, len)
  x.label("sys_08");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.movRegSib32(R.ESI, R.EBP, R.EDI, 0, 4);
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 8);
  x.movRegReg32(R.EDI, R.EAX);
  x.addRegReg32(R.EDI, R.EBP);
  x.addRegReg32(R.ESI, R.EBP);
  x.cmpRegImm32(R.ECX, 0);
  x.jleLabel("mc8_done");
  x.repMovsb();
  x.label("mc8_done");
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  // SYS 9: MEMSET(dst, val, len)
  x.label("sys_09");
  x.pushReg32(R.EDI);
  x.movRegSib32(R.EBX, R.EBP, R.EDI, 0, 0);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 4);
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 8);
  x.movRegReg32(R.EDI, R.EBX);
  x.addRegReg32(R.EDI, R.EBP);
  x.cmpRegImm32(R.ECX, 0);
  x.jleLabel("ms9_done");
  x.repStosb();
  x.label("ms9_done");
  x.popReg32(R.EDI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  // SYS 10: DISK_SYNC(start_sector, sector_count)
  // Uses 8237 DMA + 82077AA FDC when ADDR_HAS_FDC == 1, or falls back to
  // 16-bit Real-Mode BIOS INT 13h AH=03h thunk at 0x7F40 when ADDR_HAS_FDC == 0!
  x.label("sys_10");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.movRegSib32(R.EBX, R.EBP, R.EDI, 0, 0); // EBX = current LBA (or 0xFFFF for APM off)
  x.movRegSib32(R.EDX, R.EBP, R.EDI, 0, 4); // EDX = remaining sectors
  x.cmpRegImm32(R.EBX, 0xFFFF);
  x.jeLabel(opts.brokenShutdownReturn ? "bios_sync_loop" : "acpi_poweroff");

  // Check if FDC is present
  x.xorRegReg32(R.ECX, R.ECX);
  x.movRegMem32(R.EAX, R.ECX, ADDR_HAS_FDC);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("bios_sync_loop");

  x.label("fdc_sync_loop");
  x.cmpRegImm32(R.EDX, 0);
  x.jleLabel("fdc_sync_done");
  x.pushReg32(R.EDX);

  x.movRegReg32(R.ESI, R.EBX);
  x.shlRegImm(R.ESI, 9);
  x.addRegImm32(R.ESI, 0x00400000);
  x.movRegImm32(R.EDI, 0x00010000);
  x.movRegImm32(R.ECX, 128);
  x.repMovsd();

  x.movRegImm32(R.EAX, 0x06); x.outImm8Al(0x0A);
  x.movRegImm32(R.EAX, 0x00); x.outImm8Al(0x0C);
  x.movRegImm32(R.EAX, 0x4A); x.outImm8Al(0x0B);
  x.movRegImm32(R.EAX, 0x00); x.outImm8Al(0x04);
  x.movRegImm32(R.EAX, 0x00); x.outImm8Al(0x04);
  x.movRegImm32(R.EAX, 0x01); x.outImm8Al(0x81);
  x.movRegImm32(R.EAX, 0xFF); x.outImm8Al(0x05);
  x.movRegImm32(R.EAX, 0x01); x.outImm8Al(0x05);
  x.movRegImm32(R.EAX, 0x02); x.outImm8Al(0x0A);

  x.movRegReg32(R.EAX, R.EBX);
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegImm32(R.ECX, 18);
  x.divReg32(R.ECX);
  x.addRegImm32(R.EDX, 1);
  x.movRegReg32(R.ECX, R.EAX);
  x.andRegImm32(R.ECX, 1);
  x.shrRegImm(R.EAX, 1);
  x.movRegReg32(R.ESI, R.EAX);
  x.movRegReg32(R.EDI, R.EDX);

  const fdcOut = (regOrImm, isReg = false) => {
    x.movRegImm32(R.EDX, 0x03F5);
    if (!isReg) x.movRegImm32(R.EAX, regOrImm);
    else if (regOrImm !== R.EAX) x.movRegReg32(R.EAX, regOrImm);
    x.outDxAl();
  };
  fdcOut(0xC5);
  x.movRegReg32(R.EAX, R.ECX); x.shlRegImm(R.EAX, 2); fdcOut(R.EAX, true);
  fdcOut(R.ESI, true);
  fdcOut(R.ECX, true);
  fdcOut(R.EDI, true);
  fdcOut(0x02);
  fdcOut(18);
  fdcOut(0x1B);
  fdcOut(0xFF);

  x.movRegImm32(R.ECX, 7);
  x.movRegImm32(R.EDX, 0x03F5);
  x.label("fdc_res_loop");
  x.inAlDx();
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("fdc_res_loop");

  x.popReg32(R.EDX);
  x.addRegImm32(R.EBX, 1);
  x.subRegImm32(R.EDX, 1);
  x.jmpLabel("fdc_sync_loop");

  // BIOS INT 13h AH=03h Real-Mode Thunk Loop (when no FDC is present)
  x.label("bios_sync_loop");
  x.cmpRegImm32(R.EDX, 0);
  x.jleLabel("fdc_sync_done");
  // Copy 1 sector (512B) from 0x00400000 + EBX*512 to bounce buffer 0x00005800
  x.movRegReg32(R.ESI, R.EBX);
  x.andRegImm32(R.ESI, 0xFFF);
  x.shlRegImm(R.ESI, 9);
  x.addRegImm32(R.ESI, 0x00400000);
  x.movRegImm32(R.EDI, 0x00005800);
  x.movRegImm32(R.ECX, 128);
  x.repMovsd();
  // Save LBA at [0x57FC], remaining EDX at [0x57F8], ESP at [0x57F4]
  x.xorRegReg32(R.ECX, R.ECX);
  x.movMemReg32(R.ECX, 0x57FC, R.EBX);
  x.movMemReg32(R.ECX, 0x57F8, R.EDX);
  x.movMemReg32(R.ECX, 0x57F4, R.ESP);
  // Disable interrupts, restore BIOS PIC/PIT, apply Real-HW Fix 2 (16-bit segs, ESP, IVT), then jump to 0x0018:0x7F40
  x.cli();
  emitPicPit(x, true);   // KEHAI REAL-HW FIX 3
  x.movRegImm32(R.EAX, 0x0020);
  x.u8(0x8E); x.u8(0xD8); // mov ds, ax
  x.u8(0x8E); x.u8(0xC0); // mov es, ax
  x.u8(0x8E); x.u8(0xD0); // mov ss, ax
  x.u8(0x8E); x.u8(0xE0); // mov fs, ax
  x.u8(0x8E); x.u8(0xE8); // mov gs, ax
  x.movRegImm32(R.ESP, 0x00007C00);
  x.u8(0x0F); x.u8(0x01); x.u8(0x1D); x.u32(0x00007FF0); // lidt [0x7FF0] (Real-Mode IVT)
  x.movRegImm32(R.EAX, 0x00000011); // PE=1, PG=0
  x.u8(0x0F); x.u8(0x22); x.u8(0xC0); // mov cr0, eax
  x.u8(0xEA); x.u32(0x00007F40); x.u16(0x0018); // jmp 0x0018:0x00007F40

  x.label("pm_bios_write_ret");
  x.movRegImm32(R.EAX, 0x0010);
  x.u8(0x8E); x.u8(0xD8);
  x.u8(0x8E); x.u8(0xC0);
  x.u8(0x8E); x.u8(0xD0);
  x.u8(0x8E); x.u8(0xE0);
  x.u8(0x8E); x.u8(0xE8);
  x.xorRegReg32(R.ECX, R.ECX);
  x.movRegMem32(R.ESP, R.ECX, 0x57F4);
  x.movRegMem32(R.EDX, R.ECX, 0x57F8);
  x.movRegMem32(R.EBX, R.ECX, 0x57FC);
  x.movRegImm32(R.EBP, 0x00200000);
  emitPicPit(x, false);  // KEHAI REAL-HW FIX 3
  x.u8(0x0F); x.u8(0x01); x.u8(0x1D); x.u32(0x00007FF8); // lidt [0x7FF8]
  x.u8(0xFB); // sti
  x.cmpRegImm32(R.EBX, 0xFFFE);
  x.jeLabel("pm_disk2_ret");
  x.addRegImm32(R.EBX, 1);
  x.subRegImm32(R.EDX, 1);
  x.jmpLabel("bios_sync_loop");

  x.label("fdc_sync_done");
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  // SYS 11: REBOOT() -> triggers hardware reset on port 0x64 (0xFE) to reboot from updated floppyImage!
  x.label("sys_11");
  x.movMemImm32(R.EBP, 0x0FFD04, 0);
  x.movRegImm32(R.EAX, 0xFE);
  x.outImm8Al(0x64);
  x.jmpLabel("vm_warm_boot");

  // SYS 12: NET_SEND(buf_ptr, len) -> StudioNet ports 0x02A0..0x02AF (if present)
  x.label("sys_12");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_HAS_SNET);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("net_rx_empty");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.addRegReg32(R.EAX, R.EBP);
  x.movRegImm32(R.EDX, 0x02A8);
  x.outDxEax();
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 4);
  x.movRegImm32(R.EDX, 0x02A6);
  x.outDxAx();
  x.movRegImm32(R.EAX, 0x01);
  x.movRegImm32(R.EDX, 0x02A2);
  x.outDxAl();
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 4);
  x.jmpLabel("sys_push_eax");

  // SYS 13: NET_RECV(buf_ptr, max_len)
  x.label("sys_13");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_HAS_SNET);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("net_rx_empty");
  x.movRegImm32(R.EDX, 0x02A2);
  x.inAlDx();
  x.andRegImm32(R.EAX, 0x01);
  x.jeLabel("net_rx_empty");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.addRegReg32(R.EAX, R.EBP);
  x.movRegImm32(R.EDX, 0x02A8);
  x.outDxEax();
  x.movRegImm32(R.EAX, 0x02);
  x.movRegImm32(R.EDX, 0x02A2);
  x.outDxAl();
  x.movRegImm32(R.EDX, 0x02A6);
  x.xorRegReg32(R.EAX, R.EAX);
  x.inAxDx();
  x.jmpLabel("sys_push_eax");
  x.label("net_rx_empty");
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  // SYS 14: NET_INFO(cmd, val)
  x.label("sys_14");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_HAS_SNET);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("net_rx_empty");
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 0);
  x.cmpRegImm32(R.ECX, 0); x.jeLabel("ni_get_id");
  x.cmpRegImm32(R.ECX, 1); x.jeLabel("ni_set_id");
  x.cmpRegImm32(R.ECX, 2); x.jeLabel("ni_get_tx");
  x.movRegImm32(R.EDX, 0x02AE); x.xorRegReg32(R.EAX, R.EAX); x.inAxDx(); x.jmpLabel("sys_push_eax");
  x.label("ni_get_id");
  x.movRegImm32(R.EDX, 0x02A4); x.xorRegReg32(R.EAX, R.EAX); x.inAxDx(); x.jmpLabel("sys_push_eax");
  x.label("ni_set_id");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 4);
  x.movRegImm32(R.EDX, 0x02A4); x.outDxAx(); x.jmpLabel("sys_push_eax");
  x.label("ni_get_tx");
  x.movRegImm32(R.EDX, 0x02AD); x.xorRegReg32(R.EAX, R.EAX); x.inAlDx(); x.jmpLabel("sys_push_eax");

  // SYS 15: SOUND_TONE(freq_hz, duration_ms, wave) -> PIT Ch2 + Port 0x61 PC Speaker
  x.label("sys_15");
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 0);
  x.cmpRegImm32(R.ECX, 20);
  x.jlLabel("snd_mute");
  x.movRegImm32(R.EAX, 1193182);
  x.xorRegReg32(R.EDX, R.EDX);
  x.divReg32(R.ECX);
  x.movRegReg32(R.ECX, R.EAX);
  x.movRegImm32(R.EAX, 0xB6); x.outImm8Al(0x43);
  x.movRegReg32(R.EAX, R.ECX); x.outImm8Al(0x42);
  x.shrRegImm(R.EAX, 8); x.outImm8Al(0x42);
  x.inAlImm8(0x61);
  x.orRegImm32(R.EAX, 3);
  x.outImm8Al(0x61);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");
  x.label("snd_mute");
  x.inAlImm8(0x61);
  x.andRegImm32(R.EAX, 0xFC);
  x.outImm8Al(0x61);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  // SYS 16: MACHINE_INFO(query) -> 0: machineId(2), 1: vmRamSize(4MB), 2: icnt, 3: nodeId(0x0201), 4: hasSnet
  x.label("sys_16");
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 0);
  x.cmpRegImm32(R.ECX, 0); x.jeLabel("mi16_0");
  x.cmpRegImm32(R.ECX, 1); x.jeLabel("mi16_1");
  x.cmpRegImm32(R.ECX, 2); x.jeLabel("mi16_2");
  x.cmpRegImm32(R.ECX, 4); x.jeLabel("mi16_4");
  x.movRegImm32(R.EAX, 0x0201); x.jmpLabel("sys_push_eax");
  x.label("mi16_0"); x.movRegImm32(R.EAX, 2); x.jmpLabel("sys_push_eax");
  x.label("mi16_1"); x.xorRegReg32(R.EDX, R.EDX); x.movRegMem32(R.EAX, R.EDX, ADDR_VM_RAM_SIZE); x.jmpLabel("sys_push_eax");
  x.label("mi16_2"); x.xorRegReg32(R.EDX, R.EDX); x.movRegMem32(R.EAX, R.EDX, ADDR_VM_ICNT); x.jmpLabel("sys_push_eax");
  x.label("mi16_4"); x.xorRegReg32(R.EDX, R.EDX); x.movRegMem32(R.EAX, R.EDX, ADDR_HAS_SNET); x.jmpLabel("sys_push_eax");

  // SYS 17: BLIT_RECT(x, y, w, h, src_ptr)
  x.label("sys_17");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.movRegSib32(R.EBX, R.EBP, R.EDI, 0, 4);
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 8);
  x.movRegSib32(R.EDX, R.EBP, R.EDI, 0, 12);
  x.movRegSib32(R.ESI, R.EBP, R.EDI, 0, 16);
  x.addRegReg32(R.ESI, R.EBP);
  x.movRegImm32(R.EDI, 320);
  x.imulRegReg32(R.EBX, R.EDI);
  x.addRegReg32(R.EBX, R.EAX);
  x.addRegImm32(R.EBX, 0x002F0000);
  x.movRegReg32(R.EAX, R.ECX);
  x.cmpRegImm32(R.EAX, 0); x.jleLabel("br17_done");
  x.cmpRegImm32(R.EDX, 0); x.jleLabel("br17_done");
  x.label("br17_row");
  x.movRegReg32(R.EDI, R.EBX);
  x.movRegReg32(R.ECX, R.EAX);
  x.repMovsb();
  x.addRegImm32(R.EBX, 320);
  x.subRegImm32(R.EDX, 1);
  x.jneLabel("br17_row");
  x.label("br17_done");
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  // SYS 18: STRCMP(s1, s2)
  x.label("sys_18");
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 0);
  x.movRegSib32(R.EDX, R.EBP, R.EDI, 0, 4);
  x.addRegReg32(R.ECX, R.EBP);
  x.addRegReg32(R.EDX, R.EBP);
  x.label("sc18_loop");
  x.movzxRegMem8(R.EAX, R.ECX, 0);
  x.movzxRegMem8(R.EBX, R.EDX, 0);
  x.cmpRegReg32(R.EAX, R.EBX);
  x.jneLabel("sc18_diff");
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("sc18_same");
  x.addRegImm32(R.ECX, 1);
  x.addRegImm32(R.EDX, 1);
  x.jmpLabel("sc18_loop");
  x.label("sc18_diff"); x.xorRegReg32(R.EAX, R.EAX); x.jmpLabel("sys_push_eax");
  x.label("sc18_same"); x.movRegImm32(R.EAX, 1); x.jmpLabel("sys_push_eax");

  // SYS 19: STRLEN(s)
  x.label("sys_19");
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 0);
  x.addRegReg32(R.ECX, R.EBP);
  x.xorRegReg32(R.EAX, R.EAX);
  x.label("sl19_loop");
  x.movzxRegMem8(R.EBX, R.ECX, 0);
  x.cmpRegImm32(R.EBX, 0);
  x.jeLabel("sys_push_eax");
  x.addRegImm32(R.EAX, 1);
  x.addRegImm32(R.ECX, 1);
  x.jmpLabel("sl19_loop");

  // SYS 20: INT_TO_STR(val, buf_ptr, base)
  x.label("sys_20");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.movRegSib32(R.EBX, R.EBP, R.EDI, 0, 4);
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 8);
  x.addRegReg32(R.EBX, R.EBP);
  x.cmpRegImm32(R.EAX, 0);
  x.jneLabel("itoa20_nz");
  x.movRegImm32(R.EDX, 48); x.movMemReg8(R.EBX, 0, R.DL);
  x.xorRegReg32(R.EDX, R.EDX); x.movMemReg8(R.EBX, 1, R.DL);
  x.popReg32(R.EDI); x.popReg32(R.ESI);
  x.movRegImm32(R.EAX, 1); x.jmpLabel("sys_push_eax");

  x.label("itoa20_nz");
  x.xorRegReg32(R.ESI, R.ESI);
  x.cmpRegImm32(R.ECX, 10);
  x.jneLabel("itoa20_pos");
  x.cmpRegImm32(R.EAX, 0);
  x.jgeLabel("itoa20_pos");
  x.movRegImm32(R.ESI, 1);
  x.negReg32(R.EAX);
  x.label("itoa20_pos");
  x.movRegImm32(R.EDI, 0);
  x.label("itoa20_div");
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("itoa20_div_done");
  x.xorRegReg32(R.EDX, R.EDX);
  x.divReg32(R.ECX);
  x.cmpRegImm32(R.EDX, 10);
  x.jlLabel("itoa20_dec");
  x.addRegImm32(R.EDX, 55);
  x.jmpLabel("itoa20_store");
  x.label("itoa20_dec");
  x.addRegImm32(R.EDX, 48);
  x.label("itoa20_store");
  x.movMemReg8(R.EDI, 0x7300, R.DL);
  x.addRegImm32(R.EDI, 1);
  x.jmpLabel("itoa20_div");

  x.label("itoa20_div_done");
  x.movRegReg32(R.EAX, R.EDI);
  x.cmpRegImm32(R.ESI, 0);
  x.jeLabel("itoa20_rev");
  x.movRegImm32(R.EDX, 45);
  x.movMemReg8(R.EBX, 0, R.DL);
  x.addRegImm32(R.EBX, 1);
  x.addRegImm32(R.EAX, 1);

  x.label("itoa20_rev");
  x.cmpRegImm32(R.EDI, 0);
  x.jeLabel("itoa20_end");
  x.subRegImm32(R.EDI, 1);
  x.movzxRegMem8(R.EDX, R.EDI, 0x7300);
  x.movMemReg8(R.EBX, 0, R.DL);
  x.addRegImm32(R.EBX, 1);
  x.jmpLabel("itoa20_rev");

  x.label("itoa20_end");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movMemReg8(R.EBX, 0, R.DL);
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.jmpLabel("sys_push_eax");

  // SYS 21: TASK_SPAWN_VM(fn_pc, arg0) -> tid (1..7) or -1
  x.label("sys_21");
  x.pushReg32(R.ESI);
  x.movRegSib32(R.ESI, R.EBP, R.EDI, 0, 0); // ESI = fn_pc
  x.movRegSib32(R.EDX, R.EBP, R.EDI, 0, 4); // EDX = arg0
  x.movRegImm32(R.ECX, 1);                  // ECX = candidate tid = 1..7
  x.label("ts21_find");
  x.movRegReg32(R.EBX, R.ECX);
  x.shlRegImm(R.EBX, 5);
  x.addRegReg32(R.EBX, R.EBP);
  x.addRegImm32(R.EBX, 0x0FFE00);           // EBX = &TCB[tid]
  x.movRegMem32(R.EAX, R.EBX, 0);           // state
  x.cmpRegImm32(R.EAX, 1);
  x.jneLabel("ts21_found");
  x.addRegImm32(R.ECX, 1);
  x.cmpRegImm32(R.ECX, 8);
  x.jlLabel("ts21_find");
  x.popReg32(R.ESI);
  x.movRegImm32(R.EAX, -1);
  x.jmpLabel("sys_push_eax");

  x.label("ts21_found");
  // EAX = sp_base = 0x140000 + tid * 0x6000
  x.movRegReg32(R.EAX, R.ECX);
  x.movRegImm32(R.EBX, 0x006000);
  x.imulRegReg32(R.EAX, R.EBX);
  x.addRegImm32(R.EAX, 0x00140000);
  // Push arg0 at vmRam[sp_base]
  x.movSibReg32(R.EBP, R.EAX, 0, 0, R.EDX);
  // EDX = csp_base = 0x178000 + tid * 0x2000
  x.movRegReg32(R.EDX, R.ECX);
  x.shlRegImm(R.EDX, 13);
  x.addRegImm32(R.EDX, 0x00178000);
  x.movRegImm32(R.EBX, -1);
  x.movSibReg32(R.EBP, R.EDX, 0, 0, R.EBX); // sentinel PC = -1
  x.movSibReg32(R.EBP, R.EDX, 0, 4, R.EAX); // sentinel FP = sp_base

  // Populate TCB[tid]
  x.movRegReg32(R.EBX, R.ECX);
  x.shlRegImm(R.EBX, 5);
  x.addRegReg32(R.EBX, R.EBP);
  x.addRegImm32(R.EBX, 0x0FFE00);
  x.movMemImm32(R.EBX, 0, 1);               // state = 1 (ACTIVE)
  x.movMemReg32(R.EBX, 4, R.ESI);           // vm_pc = fn_pc
  x.movMemReg32(R.EBX, 12, R.EAX);          // vm_fp = sp_base
  x.addRegImm32(R.EAX, 4);
  x.movMemReg32(R.EBX, 8, R.EAX);           // vm_sp = sp_base + 4
  x.addRegImm32(R.EDX, 8);
  x.movMemReg32(R.EBX, 16, R.EDX);          // vm_csp = csp_base + 8
  x.movMemImm32(R.EBX, 20, 0);              // ticks = 0
  x.movMemReg32(R.EBX, 24, R.ESI);          // entry_pc
  x.movMemImm32(R.EBX, 28, 0);              // exit_val = 0

  // Increment num_active_tids at [EBP + 0x0FFF04]
  x.movRegMem32(R.EAX, R.EBP, 0x0FFF04);
  x.addRegImm32(R.EAX, 1);
  x.movMemReg32(R.EBP, 0x0FFF04, R.EAX);
  x.movRegReg32(R.EAX, R.ECX);              // return tid
  x.popReg32(R.ESI);
  x.jmpLabel("sys_push_eax");

  // Subroutine: read CMOS register AL and convert BCD -> binary if Status Reg B bit 2 is 0
  x.label("sub_read_cmos");
  x.outImm8Al(0x70);
  x.xorRegReg32(R.EAX, R.EAX);
  x.inAlImm8(0x71);
  x.movRegReg32(R.ECX, R.EAX);
  x.movRegImm32(R.EAX, 0x0B);
  x.outImm8Al(0x70);
  x.xorRegReg32(R.EAX, R.EAX);
  x.inAlImm8(0x71);
  x.andRegImm32(R.EAX, 4);
  x.jneLabel("cmos_is_bin");
  x.movRegReg32(R.EAX, R.ECX);
  x.movRegReg32(R.EBX, R.EAX);
  x.andRegImm32(R.EBX, 15);
  x.shrRegImm(R.EAX, 4);
  x.andRegImm32(R.EAX, 15);
  x.movRegImm32(R.ECX, 10);
  x.imulRegReg32(R.EAX, R.ECX);
  x.addRegReg32(R.EAX, R.EBX);
  x.ret();
  x.label("cmos_is_bin");
  x.movRegReg32(R.EAX, R.ECX);
  x.ret();

  // SYS 22: DATE() -> reads CMOS RTC (ports 0x70/0x71), writes [year, month, day, hour, min, sec]
  // to vmRam[0x0FFD90..0x0FFDA4], and returns packed (year << 16) | (month << 8) | day.
  x.label("sys_22");
  x.pushReg32(R.ESI);
  x.movRegImm32(R.EAX, 0x00); x.callLabel("sub_read_cmos"); x.movMemReg32(R.EBP, 0x0FFDA4, R.EAX); // sec
  x.movRegImm32(R.EAX, 0x02); x.callLabel("sub_read_cmos"); x.movMemReg32(R.EBP, 0x0FFDA0, R.EAX); // min
  x.movRegImm32(R.EAX, 0x04); x.callLabel("sub_read_cmos"); x.movMemReg32(R.EBP, 0x0FFD9C, R.EAX); // hour
  x.movRegImm32(R.EAX, 0x07); x.callLabel("sub_read_cmos"); x.movMemReg32(R.EBP, 0x0FFD98, R.EAX); // day
  x.movRegImm32(R.EAX, 0x08); x.callLabel("sub_read_cmos"); x.movMemReg32(R.EBP, 0x0FFD94, R.EAX); // month
  x.movRegImm32(R.EAX, 0x32); x.callLabel("sub_read_cmos"); // century
  x.cmpRegImm32(R.EAX, 0);
  x.jneLabel("cmos_cent_ok");
  x.movRegImm32(R.EAX, 20);
  x.label("cmos_cent_ok");
  x.movRegImm32(R.ECX, 100);
  x.imulRegReg32(R.EAX, R.ECX);
  x.movRegReg32(R.ESI, R.EAX);
  x.movRegImm32(R.EAX, 0x09); x.callLabel("sub_read_cmos"); // 2-digit year
  x.addRegReg32(R.EAX, R.ESI);
  x.movMemReg32(R.EBP, 0x0FFD90, R.EAX); // full year
  x.shlRegImm(R.EAX, 16);
  x.movRegMem32(R.ECX, R.EBP, 0x0FFD94);
  x.shlRegImm(R.ECX, 8);
  x.orRegReg32(R.EAX, R.ECX);
  x.movRegMem32(R.ECX, R.EBP, 0x0FFD98);
  x.orRegReg32(R.EAX, R.ECX);
  x.popReg32(R.ESI);
  x.jmpLabel("sys_push_eax");

  x.label("sub_call_rm_disk2");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.pushReg32(R.EBX);
  x.xorRegReg32(R.ECX, R.ECX);
  x.movMemImm32(R.ECX, 0x57FC, 0xFFFE);
  x.movMemReg32(R.ECX, 0x57F4, R.ESP);
  x.cli();
  emitPicPit(x, true);
  x.movRegImm32(R.EAX, 0x0020);
  x.u8(0x8E); x.u8(0xD8);
  x.u8(0x8E); x.u8(0xC0);
  x.u8(0x8E); x.u8(0xD0);
  x.u8(0x8E); x.u8(0xE0);
  x.u8(0x8E); x.u8(0xE8);
  x.movRegImm32(R.ESP, 0x00007C00);
  x.u8(0x0F); x.u8(0x01); x.u8(0x1D); x.u32(0x00007FF0);
  x.movRegImm32(R.EAX, 0x00000011);
  x.u8(0x0F); x.u8(0x22); x.u8(0xC0);
  x.u8(0xEA); x.u32(0x00007F40); x.u16(0x0018);
  x.label("pm_disk2_ret");
  x.popReg32(R.EBX);
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.xorRegReg32(R.ECX, R.ECX);
  x.movRegMem32(R.EAX, R.ECX, 0x57D4);
  x.ret();

  // SYS 23: DISK2_INFO(cmd)
  x.label("sys_23");
  x.xorRegReg32(R.ECX, R.ECX);
  x.movMemImm32(R.ECX, 0x57E0, 0);
  x.callLabel("sub_call_rm_disk2");
  x.jmpLabel("sys_push_eax");

  // SYS 24: DISK2_READ(lba, count, dst_vm_ptr)
  x.label("sys_24");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.movRegSib32(R.EBX, R.EBP, R.EDI, 0, 4);
  x.movRegSib32(R.EDX, R.EBP, R.EDI, 0, 8);
  x.addRegReg32(R.EDX, R.EBP);
  x.label("d2_rd_lp");
  x.cmpRegImm32(R.EBX, 0);
  x.jleLabel("d2_rw_ok");
  x.movRegReg32(R.ESI, R.EBX);
  x.cmpRegImm32(R.ESI, 4);
  x.jleLabel("d2_rd_cnt_ok");
  x.movRegImm32(R.ESI, 4);
  x.label("d2_rd_cnt_ok");
  x.xorRegReg32(R.ECX, R.ECX);
  x.movMemImm32(R.ECX, 0x57E0, 1);
  x.movMemReg32(R.ECX, 0x57DC, R.EAX);
  x.movMemReg32(R.ECX, 0x57D8, R.ESI);
  x.pushReg32(R.EAX); x.pushReg32(R.EBX); x.pushReg32(R.EDX); x.pushReg32(R.ESI);
  x.callLabel("sub_call_rm_disk2");
  x.popReg32(R.ESI); x.popReg32(R.EDX); x.popReg32(R.EBX); x.popReg32(R.ECX);
  x.cmpRegImm32(R.EAX, 0);
  x.jneLabel("d2_rw_err");
  x.movRegReg32(R.EAX, R.ECX);
  x.pushReg32(R.EAX); x.pushReg32(R.ESI);
  x.movRegReg32(R.ECX, R.ESI);
  x.shlRegImm(R.ECX, 7);
  x.movRegImm32(R.ESI, 0x00005800);
  x.movRegReg32(R.EDI, R.EDX);
  x.repMovsd();
  x.movRegReg32(R.EDX, R.EDI);
  x.popReg32(R.ESI); x.popReg32(R.EAX);
  x.addRegReg32(R.EAX, R.ESI);
  x.subRegReg32(R.EBX, R.ESI);
  x.jmpLabel("d2_rd_lp");

  // SYS 25: DISK2_WRITE(lba, count, src_vm_ptr)
  x.label("sys_25");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, 0);
  x.movRegSib32(R.EBX, R.EBP, R.EDI, 0, 4);
  x.movRegSib32(R.EDX, R.EBP, R.EDI, 0, 8);
  x.addRegReg32(R.EDX, R.EBP);
  x.label("d2_wr_lp");
  x.cmpRegImm32(R.EBX, 0);
  x.jleLabel("d2_rw_ok");
  x.movRegReg32(R.ESI, R.EBX);
  x.cmpRegImm32(R.ESI, 4);
  x.jleLabel("d2_wr_cnt_ok");
  x.movRegImm32(R.ESI, 4);
  x.label("d2_wr_cnt_ok");
  x.pushReg32(R.EAX); x.pushReg32(R.ESI);
  x.movRegReg32(R.ECX, R.ESI);
  x.shlRegImm(R.ECX, 7);
  x.movRegReg32(R.ESI, R.EDX);
  x.movRegImm32(R.EDI, 0x00005800);
  x.repMovsd();
  x.movRegReg32(R.EDX, R.ESI);
  x.popReg32(R.ESI); x.popReg32(R.EAX);
  x.xorRegReg32(R.ECX, R.ECX);
  x.movMemImm32(R.ECX, 0x57E0, 2);
  x.movMemReg32(R.ECX, 0x57DC, R.EAX);
  x.movMemReg32(R.ECX, 0x57D8, R.ESI);
  x.pushReg32(R.EAX); x.pushReg32(R.EBX); x.pushReg32(R.EDX); x.pushReg32(R.ESI);
  x.callLabel("sub_call_rm_disk2");
  x.popReg32(R.ESI); x.popReg32(R.EDX); x.popReg32(R.EBX); x.popReg32(R.ECX);
  x.cmpRegImm32(R.EAX, 0);
  x.jneLabel("d2_rw_err");
  x.movRegReg32(R.EAX, R.ECX);
  x.addRegReg32(R.EAX, R.ESI);
  x.subRegReg32(R.EBX, R.ESI);
  x.jmpLabel("d2_wr_lp");

  x.label("d2_rw_ok");
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");

  x.label("d2_rw_err");
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.movRegImm32(R.EAX, -1);
  x.jmpLabel("sys_push_eax");

  // SYS 26: AUDIO_INFO(cmd)
  x.label("sys_26");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_HAS_SB16);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("sys_push_eax");
  x.movRegSib32(R.EBX, R.EBP, R.EDI, 0, 0);
  x.cmpRegImm32(R.EBX, 0);
  x.jeLabel("a26_caps");
  x.cmpRegImm32(R.EBX, 1);
  x.jeLabel("a26_rate");
  x.cmpRegImm32(R.EBX, 3);
  x.jeLabel("a26_cap");
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");
  x.label("a26_caps"); x.movRegImm32(R.EAX, 7); x.jmpLabel("sys_push_eax");
  x.label("a26_rate"); x.movRegImm32(R.EAX, 22050); x.jmpLabel("sys_push_eax");
  x.label("a26_cap");  x.movRegImm32(R.EAX, 4096); x.jmpLabel("sys_push_eax");

  // SYS 27: AUDIO_WRITE(src_vm_ptr, num_frames) -> SB16 16-bit Stereo DMA (8237 Ch 5 + DSP 0xB0)
  x.label("sys_27");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EDX, ADDR_HAS_SB16);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("a27_absent");
  x.pushReg32(R.ESI);
  x.pushReg32(R.EDI);
  x.movRegSib32(R.ESI, R.EBP, R.EDI, 0, 0);
  x.addRegReg32(R.ESI, R.EBP);
  x.movRegSib32(R.ECX, R.EBP, R.EDI, 0, 4);
  x.cmpRegImm32(R.ECX, 0);
  x.jleLabel("a27_done_zero");
  x.cmpRegImm32(R.ECX, 4096);
  x.jleLabel("a27_cnt_ok");
  x.movRegImm32(R.ECX, 4096);
  x.label("a27_cnt_ok");
  x.movRegReg32(R.EBX, R.ECX);
  x.movRegImm32(R.EDI, 0x00010000);
  x.repMovsd();
  x.movRegImm32(R.EAX, 0x05); x.outImm8Al(0xD4);
  x.xorRegReg32(R.EAX, R.EAX); x.outImm8Al(0xD8);
  x.movRegImm32(R.EAX, 0x49); x.outImm8Al(0xD6);
  x.xorRegReg32(R.EAX, R.EAX); x.outImm8Al(0x8B);
  x.xorRegReg32(R.EAX, R.EAX); x.outImm8Al(0xC4);
  x.movRegImm32(R.EAX, 0x80); x.outImm8Al(0xC4);
  x.movRegReg32(R.ECX, R.EBX);
  x.shlRegImm(R.ECX, 1);
  x.subRegImm32(R.ECX, 1);
  x.movRegReg32(R.EAX, R.ECX); x.outImm8Al(0xC6);
  x.shrRegImm(R.EAX, 8);       x.outImm8Al(0xC6);
  x.movRegImm32(R.EAX, 0x01); x.outImm8Al(0xD4);
  x.movRegImm32(R.EDX, 0x022C);
  x.movRegImm32(R.EAX, 0xB0); x.outDxAl();
  x.movRegImm32(R.EAX, 0x30); x.outDxAl();
  x.movRegReg32(R.EAX, R.ECX); x.outDxAl();
  x.shrRegImm(R.EAX, 8);       x.outDxAl();
  x.movRegImm32(R.EDX, 0x022F); x.inAlDx();
  x.movRegImm32(R.EAX, 0x20); x.outImm8Al(0x20);
  x.movRegReg32(R.EAX, R.EBX);
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.jmpLabel("sys_push_eax");
  x.label("a27_done_zero");
  x.popReg32(R.EDI);
  x.popReg32(R.ESI);
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("sys_push_eax");
  x.label("a27_absent");
  x.movRegImm32(R.EAX, -1);
  x.jmpLabel("sys_push_eax");

  // ==========================================================================
  // 4. VM Task Exit / Halt & Jump Tables
  // ==========================================================================

  // ==========================================================================
  // 3b. ACPI S5 Protected-Mode Power-Off (with APM Fallback, Never Reboots)
  // ==========================================================================
  // Helper: identity-map 4 MB page containing physical address EAX (if >= 8 MB)
  x.label("sub_acpi_map_page");
  x.cmpRegImm32(R.EAX, 0x00800000);
  x.jbLabel("acpi_map_ret");
  x.pushReg32(R.EBX);
  x.pushReg32(R.ECX);
  x.movRegReg32(R.EBX, R.EAX);
  x.shrRegImm(R.EBX, 22);           // PDE index
  x.movRegReg32(R.ECX, R.EAX);
  x.andRegImm32(R.ECX, 0xFFC00000);
  x.orRegImm32(R.ECX, 0x00000083);  // 4 MB Present | RW | PS
  x.shlRegImm(R.EBX, 2);
  x.movMemReg32(R.EBX, 0x00006000, R.ECX);
  x.pushReg32(R.EAX);
  x.movRegImm32(R.EAX, 0x00006000);
  x.u8(0x0F); x.u8(0x22); x.u8(0xD8); // mov cr3, eax (TLB flush)
  x.popReg32(R.EAX);
  x.popReg32(R.ECX);
  x.popReg32(R.EBX);
  x.label("acpi_map_ret");
  x.ret();

  // Helper: scan [ESI .. EDI) step 16 for valid "RSD PTR " with 20-byte checksum == 0
  // Returns ESI = RSDP address, or 0 if not found
  x.label("sub_acpi_scan_rsdp");
  x.label("rsdp_scan_lp");
  x.cmpRegReg32(R.ESI, R.EDI);
  x.jgeLabel("rsdp_not_here");
  x.movRegMem32(R.EAX, R.ESI, 0);
  x.cmpRegImm32(R.EAX, 0x20445352); // "RSD "
  x.jneLabel("rsdp_scan_next");
  x.movRegMem32(R.EAX, R.ESI, 4);
  x.cmpRegImm32(R.EAX, 0x20525450); // "PTR "
  x.jneLabel("rsdp_scan_next");
  // Verify 20-byte ACPI 1.0 checksum
  x.xorRegReg32(R.EAX, R.EAX);
  x.xorRegReg32(R.ECX, R.ECX);
  x.label("rsdp_ck_lp");
  x.movzxRegSib8(R.EBX, R.ESI, R.ECX, 0, 0);
  x.addRegReg32(R.EAX, R.EBX);
  x.addRegImm32(R.ECX, 1);
  x.cmpRegImm32(R.ECX, 20);
  x.jbLabel("rsdp_ck_lp");
  x.andRegImm32(R.EAX, 0xFF);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("rsdp_found_ret");
  x.label("rsdp_scan_next");
  x.addRegImm32(R.ESI, 16);
  x.jmpLabel("rsdp_scan_lp");
  x.label("rsdp_not_here");
  x.xorRegReg32(R.ESI, R.ESI);
  x.label("rsdp_found_ret");
  x.ret();

  x.label("acpi_poweroff");
  x.cli();
  // Step 1: Search EBDA (1 KB at *(u16*)0x040E << 4)
  x.xorRegReg32(R.EBX, R.EBX);
  x.u8(0x0F); x.u8(0xB7); x.memRegDisp(R.ESI, R.EBX, 0x040E); // movzx esi, word [0x040E]
  x.shlRegImm(R.ESI, 4);
  x.cmpRegImm32(R.ESI, 0x00080000);
  x.jbLabel("acpi_scan_bios");
  x.cmpRegImm32(R.ESI, 0x000A0000);
  x.jgeLabel("acpi_scan_bios");
  x.movRegReg32(R.EDI, R.ESI);
  x.addRegImm32(R.EDI, 1024);
  x.callLabel("sub_acpi_scan_rsdp");
  x.cmpRegImm32(R.ESI, 0);
  x.jneLabel("acpi_got_rsdp");

  // Step 1b: Search main BIOS ROM area 0xE0000..0xFFFFF
  x.label("acpi_scan_bios");
  x.movRegImm32(R.ESI, 0x000E0000);
  x.movRegImm32(R.EDI, 0x00100000);
  x.callLabel("sub_acpi_scan_rsdp");
  x.cmpRegImm32(R.ESI, 0);
  x.jneLabel("acpi_got_rsdp");
  x.movMemImm32(R.EBP, 0x0FFDB0, 2); // status 2: RSDP not found
  x.jmpLabel("acpi_fallback_apm");

  // Step 2: Walk RSDT -> find FACP (FADT)
  x.label("acpi_got_rsdp");
  x.movRegMem32(R.ESI, R.ESI, 16);   // ESI = RsdtAddress
  x.cmpRegImm32(R.ESI, 0);
  x.jeLabel("acpi_no_facp");
  x.movRegReg32(R.EAX, R.ESI);
  x.callLabel("sub_acpi_map_page");
  x.movRegMem32(R.EAX, R.ESI, 0);
  x.cmpRegImm32(R.EAX, 0x54445352);  // "RSDT"
  x.jneLabel("acpi_no_facp");
  x.movRegMem32(R.ECX, R.ESI, 4);    // RSDT Length
  x.cmpRegImm32(R.ECX, 36);
  x.jbLabel("acpi_no_facp");
  x.movRegReg32(R.EDI, R.ESI);
  x.addRegReg32(R.EDI, R.ECX);       // EDI = RSDT end
  x.addRegImm32(R.ESI, 36);          // ESI = first entry pointer
  x.label("acpi_rsdt_lp");
  x.movRegReg32(R.EAX, R.ESI);
  x.addRegImm32(R.EAX, 4);
  x.cmpRegReg32(R.EAX, R.EDI);
  x.jaLabel("acpi_no_facp");
  x.movRegMem32(R.EBX, R.ESI, 0);    // EBX = table physical address
  x.addRegImm32(R.ESI, 4);
  x.cmpRegImm32(R.EBX, 0);
  x.jeLabel("acpi_rsdt_lp");
  x.movRegReg32(R.EAX, R.EBX);
  x.callLabel("sub_acpi_map_page");
  x.movRegMem32(R.EAX, R.EBX, 0);
  x.cmpRegImm32(R.EAX, 0x50434146);  // "FACP"
  x.jneLabel("acpi_rsdt_lp");

  // Step 3: Read FADT fields into scratch at 0x000051C0..0x000051DF
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.EAX, R.EBX, 40);   // DSDT address
  x.movMemReg32(R.EDX, 0x51C0, R.EAX);
  x.movRegMem32(R.EAX, R.EBX, 48);   // SMI_CMD
  x.movMemReg32(R.EDX, 0x51C4, R.EAX);
  x.movzxRegMem8(R.EAX, R.EBX, 52);  // ACPI_ENABLE
  x.movMemReg32(R.EDX, 0x51C8, R.EAX);
  x.movRegMem32(R.EAX, R.EBX, 64);   // PM1a_CNT_BLK
  x.movMemReg32(R.EDX, 0x51CC, R.EAX);
  x.movRegMem32(R.EAX, R.EBX, 68);   // PM1b_CNT_BLK
  x.movMemReg32(R.EDX, 0x51D0, R.EAX);

  x.movRegMem32(R.EAX, R.EDX, 0x51CC);
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("acpi_no_facp");
  x.movRegMem32(R.ESI, R.EDX, 0x51C0);
  x.cmpRegImm32(R.ESI, 0);
  x.jeLabel("acpi_no_facp");

  // Step 4: Map DSDT & scan for AML NameOp [RootChar] "_S5_" PackageOp
  x.movRegReg32(R.EAX, R.ESI);
  x.callLabel("sub_acpi_map_page");
  x.movRegMem32(R.EAX, R.ESI, 0);
  x.cmpRegImm32(R.EAX, 0x54445344);  // "DSDT"
  x.jneLabel("acpi_no_s5");
  x.movRegMem32(R.ECX, R.ESI, 4);    // DSDT Length
  x.cmpRegImm32(R.ECX, 44);
  x.jbLabel("acpi_no_s5");
  x.movRegReg32(R.EDI, R.ESI);
  x.addRegReg32(R.EDI, R.ECX);
  x.subRegImm32(R.EDI, 8);
  x.addRegImm32(R.ESI, 36);

  x.label("acpi_s5_lp");
  x.cmpRegReg32(R.ESI, R.EDI);
  x.jgeLabel("acpi_no_s5");
  x.movRegMem32(R.EAX, R.ESI, 0);
  x.cmpRegImm32(R.EAX, 0x5F35535F);  // "_S5_"
  x.jneLabel("acpi_s5_next");
  // Check preceding NameOp (0x08) or NameOp + RootChar (0x08, 0x5C)
  x.movzxRegMem8(R.EAX, R.ESI, -1);
  x.cmpRegImm32(R.EAX, 0x08);
  x.jeLabel("acpi_s5_chk_pkg");
  x.cmpRegImm32(R.EAX, 0x5C);
  x.jneLabel("acpi_s5_next");
  x.movzxRegMem8(R.EAX, R.ESI, -2);
  x.cmpRegImm32(R.EAX, 0x08);
  x.jneLabel("acpi_s5_next");
  x.label("acpi_s5_chk_pkg");
  x.movzxRegMem8(R.EAX, R.ESI, 4);
  x.cmpRegImm32(R.EAX, 0x12);        // PackageOp
  x.jeLabel("acpi_s5_parse");
  x.label("acpi_s5_next");
  x.addRegImm32(R.ESI, 1);
  x.jmpLabel("acpi_s5_lp");

  x.label("acpi_s5_parse");
  x.addRegImm32(R.ESI, 5);           // point at PkgLength
  x.movzxRegMem8(R.EAX, R.ESI, 0);
  x.shrRegImm(R.EAX, 6);
  x.andRegImm32(R.EAX, 3);
  x.addRegImm32(R.EAX, 2);           // skip PkgLength (1 + lead) + NumElements (1)
  x.addRegReg32(R.ESI, R.EAX);
  // Read SLP_TYPa (optional 0x0A BytePrefix)
  x.movzxRegMem8(R.EAX, R.ESI, 0);
  x.cmpRegImm32(R.EAX, 0x0A);
  x.jneLabel("acpi_slpa_raw");
  x.addRegImm32(R.ESI, 1);
  x.movzxRegMem8(R.EAX, R.ESI, 0);
  x.label("acpi_slpa_raw");
  x.addRegImm32(R.ESI, 1);
  x.andRegImm32(R.EAX, 7);
  x.shlRegImm(R.EAX, 10);
  x.orRegImm32(R.EAX, 0x2000);       // SLP_TYPa << 10 | SLP_EN
  x.xorRegReg32(R.EDX, R.EDX);
  x.movMemReg32(R.EDX, 0x51D4, R.EAX);
  // Read SLP_TYPb (optional 0x0A BytePrefix)
  x.movzxRegMem8(R.EAX, R.ESI, 0);
  x.cmpRegImm32(R.EAX, 0x0A);
  x.jneLabel("acpi_slpb_raw");
  x.addRegImm32(R.ESI, 1);
  x.movzxRegMem8(R.EAX, R.ESI, 0);
  x.label("acpi_slpb_raw");
  x.andRegImm32(R.EAX, 7);
  x.shlRegImm(R.EAX, 10);
  x.orRegImm32(R.EAX, 0x2000);       // SLP_TYPb << 10 | SLP_EN
  x.movMemReg32(R.EDX, 0x51D8, R.EAX);

  // Step 5: Enable ACPI if SCI_EN (bit 0 of PM1a_CNT) is 0
  x.movRegMem32(R.EDX, R.EDX, 0x51CC); // EDX = PM1a_CNT_BLK
  x.xorRegReg32(R.EAX, R.EAX);
  x.inAxDx();
  x.andRegImm32(R.EAX, 1);
  x.jneLabel("acpi_do_s5");
  x.xorRegReg32(R.EBX, R.EBX);
  x.movRegMem32(R.EDX, R.EBX, 0x51C4); // SMI_CMD
  x.cmpRegImm32(R.EDX, 0);
  x.jeLabel("acpi_do_s5");
  x.movRegMem32(R.EAX, R.EBX, 0x51C8); // ACPI_ENABLE
  x.cmpRegImm32(R.EAX, 0);
  x.jeLabel("acpi_do_s5");
  x.outDxAl();
  x.movRegImm32(R.ECX, 4096);
  x.label("acpi_en_wait");
  x.subRegImm32(R.ECX, 1);
  x.jneLabel("acpi_en_wait");

  // Write SLP_TYP | SLP_EN to PM1a_CNT (and PM1b_CNT if non-zero)
  x.label("acpi_do_s5");
  x.xorRegReg32(R.EBX, R.EBX);
  x.movRegMem32(R.EDX, R.EBX, 0x51CC); // PM1a_CNT_BLK
  x.movRegMem32(R.EAX, R.EBX, 0x51D4); // SLP_TYPa | SLP_EN
  // Record ACPI S5 write in VMRAM_STATUS (+0xB0 = 1, +0xB4 = port | (val << 16))
  x.movRegReg32(R.ECX, R.EAX);
  x.shlRegImm(R.ECX, 16);
  x.orRegReg32(R.ECX, R.EDX);
  x.movMemImm32(R.EBP, 0x0FFDB0, 1);
  x.movMemReg32(R.EBP, 0x0FFDB4, R.ECX);
  x.outDxAx();
  x.movRegMem32(R.EDX, R.EBX, 0x51D0); // PM1b_CNT_BLK
  x.cmpRegImm32(R.EDX, 0);
  x.jeLabel("acpi_s5_halt");
  x.movRegMem32(R.EAX, R.EBX, 0x51D8); // SLP_TYPb | SLP_EN
  x.outDxAx();
  x.label("acpi_s5_halt");
  // Never reboot: halt cleanly if hardware does not immediately cut power
  x.xorRegReg32(R.EAX, R.EAX);
  x.jmpLabel("vm_halt_with_eax");

  x.label("acpi_no_facp");
  x.movMemImm32(R.EBP, 0x0FFDB0, 3);
  x.jmpLabel("acpi_fallback_apm");

  x.label("acpi_no_s5");
  x.movMemImm32(R.EBP, 0x0FFDB0, 4);

  x.label("acpi_fallback_apm");
  // Fall back to Real-Mode APM 1.2 (returns cleanly to os_shutdown -> cli; hlt if unsupported)
  x.movRegImm32(R.EBX, 0xFFFF);
  x.movRegImm32(R.EDX, 1);
  x.jmpLabel("bios_sync_loop");

  x.label("vm_task_exit_or_halt");
  x.movRegSib32(R.EAX, R.EBP, R.EDI, 0, -4); // EAX = return value
  x.movRegMem32(R.ECX, R.EBP, 0x0FFF00);     // ECX = cur_tid
  x.cmpRegImm32(R.ECX, 0);
  x.jeLabel("vm_halt_with_eax");
  // Background task finished: mark TCB as HALTED (2), decrement num_active_tids, and switch!
  x.movRegReg32(R.EBX, R.ECX);
  x.shlRegImm(R.EBX, 5);
  x.addRegReg32(R.EBX, R.EBP);
  x.addRegImm32(R.EBX, 0x0FFE00);
  x.movMemImm32(R.EBX, 0, 2);                // state = 2 (HALTED)
  x.movMemReg32(R.EBX, 28, R.EAX);           // exit_val
  x.movRegMem32(R.EAX, R.EBP, 0x0FFF04);
  x.subRegImm32(R.EAX, 1);
  x.movMemReg32(R.EBP, 0x0FFF04, R.EAX);
  x.jmpLabel("sched_pick_next");

  x.label("vm_halt_bad_op");
  x.movRegImm32(R.EAX, -99);

  x.label("vm_halt_with_eax");
  x.xorRegReg32(R.EDX, R.EDX);
  x.movRegMem32(R.ECX, R.EDX, ADDR_VM_ICNT);
  x.movMemReg32(R.EBP, 0x0FFD20, R.ECX);
  x.movMemReg32(R.EBP, 0x0FFD28, R.EAX);
  x.movMemImm32(R.EBP, 0x0FFD2C, 1);
  x.cli();
  x.label("halt_spin");
  x.hlt();
  x.jmpLabel("halt_spin");

  const opLabels = [
    "op_00_nop",       "op_01_halt",      "op_02_push_i16",  "op_03_push_u16",
    "op_04_push_hi",   "op_05_dup",       "op_06_drop",      "op_07_swap",
    "op_08_get_local", "op_09_set_local", "op_0a_get_global","op_0b_set_global",
    "op_0c_addr_local","op_0d_addr_global","op_0e_load8u",   "op_0f_load8s",
    "op_10_load16u",   "op_11_load32",    "op_12_store8",    "op_13_store16",
    "op_14_store32",   "op_15_add",       "op_16_sub",       "op_17_mul",
    "op_18_div",       "op_19_mod",       "op_1a_and",       "op_1b_or",
    "op_1c_xor",       "op_1d_shl",       "op_1e_shr",       "op_1f_sar",
    "op_20_cmp",       "op_21_jmp",       "op_22_jz",        "op_23_jnz",
    "op_24_call",      "op_25_enter",     "op_26_ret",       "op_27_syscall",
    "op_28_call_ind"
  ];
  x.label("op_table");
  x.labelTable32(opLabels);

  const cmpLabels = [
    "cmp_0_eq", "cmp_1_ne", "cmp_2_lt", "cmp_3_le",
    "cmp_4_gt", "cmp_5_ge", "cmp_6_ult", "cmp_7_ugt"
  ];
  x.label("cmp_table");
  x.labelTable32(cmpLabels);

  x.label("embedded_font");
  for (let i = 0; i < 768; i++) {
    x.u8(parseInt(X86_FONT_8X8_HEX.substr(i * 2, 2), 16));
  }

  x.label("embedded_font_serif");
  for (let i = 0; i < 1536; i++) {
    x.u8(parseInt(X86_FONT_SERIF_8X16_HEX.substr(i * 2, 2), 16));
  }

  x.label("embedded_palette");
  const ega16 = [
    [0,0,0],       [0,18,110],    [0,150,40],    [0,160,160],
    [170,20,20],   [150,0,150],   [170,95,0],    [180,185,195],
    [85,90,105],   [65,125,255],  [72,255,122],  [0,240,255],
    [255,80,80],   [255,85,255],  [255,230,60],  [255,255,255]
  ];
  for (let i = 0; i < 16; i++) {
    x.u8(ega16[i][0]); x.u8(ega16[i][1]); x.u8(ega16[i][2]);
  }
  for (let i = 16; i < 256; i++) {
    x.u8((i * 37) & 255); x.u8((i * 73) & 255); x.u8((i * 139) & 255);
  }

  const plainMap = new Uint16Array(128);
  const shiftMap = new Uint16Array(128);
  const plainChars = "1234567890-=\b\tqwertyuiop[]\r\0asdfghjkl;'`\0\\zxcvbnm,./";
  const shiftChars = "!@#$%^&*()_+\b\tQWERTYUIOP{}\r\0ASDFGHJKL:\"~\0|ZXCVBNM<>?";
  for (let i = 0; i < plainChars.length; i++) {
    const sc = i + 2;
    const cp = plainChars.charCodeAt(i);
    const cs = shiftChars.charCodeAt(i);
    if (cp) plainMap[sc] = cp | ((cp >= 97 && cp <= 122 ? cp - 32 : cp) << 8);
    if (cs) shiftMap[sc] = cs | ((cp >= 97 && cp <= 122 ? cp - 32 : cp) << 8);
  }
  plainMap[0x01] = (27 << 8) | 27; shiftMap[0x01] = (27 << 8) | 27;
  plainMap[0x0E] = (8 << 8) | 8;   shiftMap[0x0E] = (8 << 8) | 8;
  plainMap[0x0F] = (9 << 8) | 9;   shiftMap[0x0F] = (9 << 8) | 9;
  plainMap[0x1C] = (13 << 8) | 13; shiftMap[0x1C] = (13 << 8) | 13;
  plainMap[0x39] = (32 << 8) | 32; shiftMap[0x39] = (32 << 8) | 32;
  plainMap[0x1D] = 2;              shiftMap[0x1D] = 2;
  plainMap[0x2A] = 1;              shiftMap[0x2A] = 1;
  plainMap[0x36] = 1;              shiftMap[0x36] = 1;
  plainMap[0x38] = 4;              shiftMap[0x38] = 4;
  for (let f = 0; f < 10; f++) {
    plainMap[0x3B + f] = ((112 + f) << 8);
    shiftMap[0x3B + f] = ((112 + f) << 8);
  }
  plainMap[0x47] = (36 << 8) | 0;  shiftMap[0x47] = (36 << 8) | 0;
  plainMap[0x48] = (38 << 8) | 0;  shiftMap[0x48] = (38 << 8) | 0;
  plainMap[0x49] = (33 << 8) | 0;  shiftMap[0x49] = (33 << 8) | 0;
  plainMap[0x4B] = (37 << 8) | 0;  shiftMap[0x4B] = (37 << 8) | 0;
  plainMap[0x4D] = (39 << 8) | 0;  shiftMap[0x4D] = (39 << 8) | 0;
  plainMap[0x4F] = (35 << 8) | 0;  shiftMap[0x4F] = (35 << 8) | 0;
  plainMap[0x50] = (40 << 8) | 0;  shiftMap[0x50] = (40 << 8) | 0;
  plainMap[0x51] = (34 << 8) | 0;  shiftMap[0x51] = (34 << 8) | 0;
  plainMap[0x52] = (45 << 8) | 0;  shiftMap[0x52] = (45 << 8) | 0;
  plainMap[0x53] = (46 << 8) | 127;shiftMap[0x53] = (46 << 8) | 127;
  plainMap[0x5B] = (91 << 8) | 0;  shiftMap[0x5B] = (91 << 8) | 0;
  plainMap[0x5C] = (91 << 8) | 0;  shiftMap[0x5C] = (91 << 8) | 0;

  x.label("scancode_plain_tbl");
  for (let i = 0; i < 128; i++) x.u16(plainMap[i]);
  x.label("scancode_shift_tbl");
  for (let i = 0; i < 128; i++) x.u16(shiftMap[i]);

  // 16-bit Real-Mode INT 15h RAM Probe (E820 -> E801 -> 88h) at < 0xFFFF, called from 0x7EC5
  x.label("rm_probe_ram");
  {
    const rb = [];
    const rput = (...a) => { for (const v of a) rb.push(v & 0xFF); };
    const rput16 = (v) => { rb.push(v & 0xFF, (v >>> 8) & 0xFF); };
    const rput32 = (v) => { rb.push(v & 0xFF, (v >>> 8) & 0xFF, (v >>> 16) & 0xFF, (v >>> 24) & 0xFF); };

    rput(0x83, 0x3E); rput16(0x51EC); rput(0x00);
    const jeDoProbe = rb.length + 1;
    rput(0x74, 0);
    rput(0xBE); rput16(1920);
    rput(0xBD); rput16(960);
    rput(0xBF); rput16(0x1000);
    rput(0xC3);
    rb[jeDoProbe] = (rb.length - (jeDoProbe + 1)) & 0xFF;
    rput(0x31, 0xED);                       // xor bp, bp
    rput(0x66, 0x31, 0xDB);                 // xor ebx, ebx
    rput(0xBF); rput16(0x5200);             // mov di, 0x5200

    const e820Lp = rb.length;
    rput(0x66, 0xB8); rput32(0x0000E820);   // mov eax, 0xE820
    rput(0x66, 0xBA); rput32(0x534D4150);   // mov edx, 'SMAP'
    rput(0x66, 0xB9); rput32(20);           // mov ecx, 20
    rput(0xCD, 0x15);                       // int 15h
    const jcE820Done = rb.length + 1;
    rput(0x72, 0);                          // jc e820_done
    rput(0x66, 0x3D); rput32(0x534D4150);   // cmp eax, 'SMAP'
    const jneE820Done = rb.length + 1;
    rput(0x75, 0);                          // jne e820_done
    rput(0x45);                             // inc bp
    rput(0x83, 0xC7, 20);                   // add di, 20
    rput(0x83, 0xFD, 32);                   // cmp bp, 32
    const jaeE820Done = rb.length + 1;
    rput(0x73, 0);                          // jae e820_done
    rput(0x66, 0x85, 0xDB);                 // test ebx, ebx
    rput(0x75, (e820Lp - (rb.length + 2)) & 0xFF);

    rb[jcE820Done] = (rb.length - (jcE820Done + 1)) & 0xFF;
    rb[jneE820Done] = (rb.length - (jneE820Done + 1)) & 0xFF;
    rb[jaeE820Done] = (rb.length - (jaeE820Done + 1)) & 0xFF;
    rput(0x85, 0xED);                       // test bp, bp
    const jnzStoreCnt = rb.length + 1;
    rput(0x75, 0);                          // jnz store_cnt

    // Fallback 1: INT 15h AX=0xE801
    rput(0xB8); rput16(0xE801);
    rput(0x31, 0xC9);
    rput(0x31, 0xD2);
    rput(0xCD, 0x15);
    const jcTry88 = rb.length + 1;
    rput(0x72, 0);
    rput(0x85, 0xC9);
    const jnzUseCx = rb.length + 1;
    rput(0x75, 0);
    rput(0x89, 0xC1);
    rput(0x89, 0xDA);
    rb[jnzUseCx] = (rb.length - (jnzUseCx + 1)) & 0xFF;
    rput(0x66, 0x0F, 0xB7, 0xC1);
    rput(0x66, 0xC1, 0xE0, 10);
    rput(0x66, 0x0F, 0xB7, 0xDA);
    rput(0x66, 0xC1, 0xE3, 16);
    rput(0x66, 0x01, 0xD8);
    const jmpSynth1 = rb.length + 1;
    rput(0xEB, 0);

    // Fallback 2: INT 15h AH=0x88
    rb[jcTry88] = (rb.length - (jcTry88 + 1)) & 0xFF;
    rput(0xB4, 0x88);
    rput(0xCD, 0x15);
    const jcFallback16 = rb.length + 1;
    rput(0x72, 0);
    rput(0x66, 0x0F, 0xB7, 0xC0);
    rput(0x66, 0xC1, 0xE0, 10);
    const jmpSynth2 = rb.length + 1;
    rput(0xEB, 0);

    // Fallback 3: 15 MB above 1 MB
    rb[jcFallback16] = (rb.length - (jcFallback16 + 1)) & 0xFF;
    rput(0x66, 0xB8); rput32(0x00F00000);

    // synth_entry:
    rb[jmpSynth1] = (rb.length - (jmpSynth1 + 1)) & 0xFF;
    rb[jmpSynth2] = (rb.length - (jmpSynth2 + 1)) & 0xFF;
    rput(0xBF); rput16(0x5200);
    rput(0x66, 0xC7, 0x05); rput32(0x00100000);
    rput(0x66, 0xC7, 0x45, 4); rput32(0);
    rput(0x66, 0x89, 0x45, 8);
    rput(0x66, 0xC7, 0x45, 12); rput32(0);
    rput(0x66, 0xC7, 0x45, 16); rput32(1);
    rput(0xBD); rput16(1);

    // store_cnt:
    rb[jnzStoreCnt] = (rb.length - (jnzStoreCnt + 1)) & 0xFF;
    rput(0x66, 0x0F, 0xB7, 0xC5);
    rput(0x66, 0xA3); rput16(0x51FC);
    rput(0xBE); rput16(960);
    rput(0xBD); rput16(960);
    rput(0xBF); rput16(0x1000);
    rput(0xC3);
    x.bytes(rb);
  }

  x.label("rm_disk2_io");
  {
    const rb = [];
    const rput = (...xs) => { for (const v of xs) rb.push(v & 0xFF); };
    const rput16 = (v) => { rput(v & 0xFF, (v >>> 8) & 0xFF); };
    // If AX == 0xFFFF -> APM 1.2 Power-Off (5301 -> 530E -> 5307)
    rput(0x3D); rput16(0xFFFF);
    const jneNotApm = rb.length + 1;
    rput(0x75, 0);
    rput(0xB8); rput16(0x5301);
    rput(0x31, 0xDB);
    rput(0xCD, 0x15);
    const jcApmRet = rb.length + 1;
    rput(0x72, 0);
    rput(0xB8); rput16(0x530E);
    rput(0x31, 0xDB);
    rput(0xB9); rput16(0x0102);
    rput(0xCD, 0x15);
    rput(0xB8); rput16(0x5307);
    rput(0x43);
    rput(0xB9); rput16(0x0003);
    rput(0xCD, 0x15);
    rb[jcApmRet] = (rb.length - (jcApmRet + 1)) & 0xFF;
    rput(0xC3);
    rb[jneNotApm] = (rb.length - (jneNotApm + 1)) & 0xFF;
    rput(0xB2, 0x81);
    rput(0xB4, 0x41);
    rput(0xBB); rput16(0x55AA);
    rput(0xCD, 0x13);
    const jncUseDl = rb.length + 1;
    rput(0x73, 0);
    rput(0x80, 0x3E); rput16(0x7DFC); rput(0x80);
    const jneFail0 = rb.length + 1;
    rput(0x75, 0);
    rput(0xB2, 0x80);
    rput(0xB4, 0x41);
    rput(0xBB); rput16(0x55AA);
    rput(0xCD, 0x13);
    const jcFail1 = rb.length + 1;
    rput(0x72, 0);
    rb[jncUseDl] = (rb.length - (jncUseDl + 1)) & 0xFF;
    rput(0x8A, 0x06); rput16(0x57E0);
    rput(0x3C, 0x00);
    const jneNotInfo = rb.length + 1;
    rput(0x75, 0);
    rput(0xBE); rput16(0x5800);
    rput(0xC7, 0x04); rput16(0x001A);
    rput(0xB4, 0x48);
    rput(0xCD, 0x13);
    const jcFail2 = rb.length + 1;
    rput(0x72, 0);
    rput(0x66, 0xA1); rput16(0x5810);
    rput(0x66, 0xA3); rput16(0x57D4);
    rput(0xC3);
    rb[jneNotInfo] = (rb.length - (jneNotInfo + 1)) & 0xFF;
    rput(0xBE); rput16(0x57C0);
    rput(0xC7, 0x04); rput16(0x0010);
    rput(0x8B, 0x0E); rput16(0x57D8);
    rput(0x89, 0x4C, 0x02);
    rput(0xC7, 0x44, 0x04); rput16(0x5800);
    rput(0xC7, 0x44, 0x06); rput16(0x0000);
    rput(0x66, 0x8B, 0x0E); rput16(0x57DC);
    rput(0x66, 0x89, 0x4C, 0x08);
    rput(0x66, 0xC7, 0x44, 0x0C, 0, 0, 0, 0);
    rput(0xB4, 0x42);
    rput(0x3C, 0x01);
    const jeDoRw = rb.length + 1;
    rput(0x74, 0);
    rput(0xB8); rput16(0x4300);
    rb[jeDoRw] = (rb.length - (jeDoRw + 1)) & 0xFF;
    rput(0xCD, 0x13);
    const jcFail3 = rb.length + 1;
    rput(0x72, 0);
    rput(0x66, 0xC7, 0x06); rput16(0x57D4); rput(0, 0, 0, 0);
    rput(0xC3);
    const failPos = rb.length;
    rb[jneFail0] = (failPos - (jneFail0 + 1)) & 0xFF;
    rb[jcFail1] = (failPos - (jcFail1 + 1)) & 0xFF;
    rb[jcFail2] = (failPos - (jcFail2 + 1)) & 0xFF;
    rb[jcFail3] = (failPos - (jcFail3 + 1)) & 0xFF;
    rput(0x66, 0x31, 0xC0);
    rput(0x80, 0x3E); rput16(0x57E0); rput(0x00);
    const jeRetZero = rb.length + 1;
    rput(0x74, 0);
    rput(0x66, 0x48);
    rb[jeRetZero] = (rb.length - (jeRetZero + 1)) & 0xFF;
    rput(0x66, 0xA3); rput16(0x57D4);
    rput(0xC3);
    x.bytes(rb);
  }

  return { bytes: x.finalize(), labels: x.labels, asmLines: x.asmLines };
}

function formatHexLines(bytesArr, startIdx, endIdx) {
  const lines = [];
  let hex = "";
  for (let i = startIdx; i < endIdx; i++) {
    hex += (bytesArr[i] & 0xFF).toString(16).padStart(2, "0");
    if (hex.length >= 64) {
      lines.push("  .hex " + hex);
      hex = "";
    }
  }
  if (hex.length > 0) lines.push("  .hex " + hex);
  return lines;
}

function buildX86Core(customBanner = "SpiralOS 1.6", opts = {}) {
  const pm = buildProtectedModeCore(opts);
  const bootSector = buildBootSector(customBanner);
  const stage2 = buildStage2Loader(pm.labels.pm_bios_write_ret, bootSector.readRangeAddr, pm.labels.pm_bios_read2_ret, pm.labels.rm_probe_ram, pm.labels.rm_disk2_io, opts);
  const combined = new Uint8Array(32 * 512); // Sectors 0..31 (16 KB)
  combined.set(bootSector, 0);
  combined.set(stage2, 512);
  combined.set(pm.bytes, 1024);

  const asmLines = [
    "; SpiralOS 1.1 — Hummingbird i586 Native Core Assembly (/src/core_x86.asm)",
    "; Stage 1 Boot Sector (0x7C00), Stage 2 Track-Safe Loader + BIOS Thunk (0x7E00),",
    "; and 32-bit Protected-Mode Core (0x8000)",
    "  .org 0x7C00",
    "stage1_boot_sector:"
  ];
  asmLines.push(...formatHexLines(bootSector, 0, 0x0180));
  asmLines.push("boot_banner:");
  asmLines.push(`  .banner "${customBanner}"`);
  asmLines.push(...formatHexLines(bootSector, 0x0190, 512));
  asmLines.push("stage2_loader:");
  asmLines.push(...formatHexLines(stage2, 0, 512));
  asmLines.push("pm_core_entry:");
  asmLines.push(...pm.asmLines);

  return {
    bootSector,
    stage2,
    pmCore: pm.bytes,
    labels: pm.labels,
    bytes: combined,
    totalBytes: 1024 + pm.bytes.length,
    bannerOffset: 0x0180,
    asmSource: asmLines.join("\n") + "\n"
  };
}

if (typeof module !== "undefined" && module.exports) {
  module.exports = { buildX86Core, buildBootSector, buildStage2Loader, buildProtectedModeCore };
}
if (typeof globalThis !== "undefined") {
  globalThis.buildX86Core = buildX86Core;
}
